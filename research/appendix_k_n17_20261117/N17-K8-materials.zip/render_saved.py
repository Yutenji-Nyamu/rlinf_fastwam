import json
from pathlib import Path
import numpy as np
from k_trace import render
p=Path(__file__).resolve().parent
with np.load(p/'action-entropy.npz') as a: arrays={k:a[k].copy() for k in a.files}
render(p,arrays,json.loads((p/'costs.json').read_text()))
