# GRPO U / Norm execution

Updated2026-10-14 China. Current formal task is move_pillbottle_pad with U tau1/2/3 and the unchanged October13 budget; see the final section. Implementation e04e9d4fbc041519019f7e642765f157ffb78553 is pushed to codex/grpo-u-n-20261009. The October9 run was a smoke; October13 formal launch and reset recovery are historical records below.

## Fixed configuration

Control: original pi0.5 turn_switch Clean256. Each smoke keeps64 environments x4 rollout epochs =256 trajectories, group8, update_epoch2, globalB512/micro32, H50/D14, 200 physical actions, seed42 and native Flow-SDE noise0.5. Enable local/chunk tau2.5, chunk dropout0.2 and the existing alpha1-to0 schedule (R1-toR200). Stop after one complete round; evaluation/checkpoint intervals are disabled for smoke. Source/config/output and physical GPU6/7 placement are the only other deployment changes.

Stop conditions: one complete round, nonfinite losses or weights, scope escape, or failed process. There is no performance threshold. Successful release requires the exact driver and Ray namespace to be gone and both compute and graphics contexts to clear.

## Validation and current results

[Server CPU tests](evidence/cpu-tests.txt): 196 passed in114.94s, CUDA disabled. Suites cover signal/sampler action and RNG parity, hooks, actual actor grouping/gradients, action-advantage losses, controls/annealing, exponential mapping and resume. Ruff0.14.3 preview lint/format and git diff checks passed. Core AST after formatting equals the server-tested source.

Both [U](evidence/u-smoke.json) and [Norm](evidence/norm-smoke.json) completed256 trajectories and2 actor-update epochs. Per-rank artifacts[4,128,50] are finite and nonconstant, with nonuniform weights. Both dropped141/715 eligible chunks (19.72%); all dropped chunk weights are exactly1. Both exited0 with cleanup_error=null; exact namespaces and GPU6/7 compute and graphics contexts were clear before return.

| Metric | U | Norm |
|---|---:|---:|
| Weight min-max | 0.61510-1.64441 | 0.59534-1.62188 |
| Global weight mean | 0.99754 | 1.00020 |
| Gradient norm | 24.64157 | 24.38032 |
| Total loss | 0.00015504 | 0.00027288 |
| Actor training seconds | 25.93 | 25.42 |
| Initial-policy rollout successes | 111/256 | 111/256 |

These success counts precede parameter updates and are smoke telemetry, not post-training evaluations. U elapsed time includes the storage stall; these runs do not establish method speed or learning quality.

Norm attempt1 exited before creating training workers because the storage switch initially missed the original Ray socket inode. Its failed-before-workers.json preserves the failure. The socket subtree was retained and new Ray connections verified; attempt2 uses identical source and budget with a new namespace/output. The final receipt passed at21:22, including renderer UUID/CUDA checks restricted to attempt2.

## Artifacts and return

Control: /data/chenyiteng/deployment-20261009/grpo-un-smoke-g67-v1. It stores plan.json, lane requests, resolved runtime configs, prelaunch scope proof, completion/release and smoke validation receipts.

Run root: /data/chenyiteng/results/rlinf-shenzhen/pi05-sidney/runs/.

- U: grpo-u-turn256-t25-tricks-smoke1-g67-20261009-v1.
- Norm: grpo-norm-turn256-t25-tricks-smoke1-g67-20261009-v2.

[Return receipt](evidence/rlt-return.json): original GPU6 Clean/GPU7 Combo both loaded complete DCP step325 and advanced to326; both began the next rollout. Max3000, original configs and requests remain unchanged. Both C/G bindings match their individual GPU; there were no scope escapes. Return owner PID1324434/start435623387 has a live heartbeat; original4/5 owner and its plan are unchanged.

Authoritative6/7 control is /data/chenyiteng/deployment-20261009/grpo-un-smoke-g67-v1/return-rlt/plan.json and status.json. The parent control has rlt-return-dispatched.json and rlt-return-verified.json. Original requests are /data/chenyiteng/deployment-20261008/bc-signal-tau-v1/requests/rlt-g6.json and rlt-g7.json. Do not dispatch them again or add6/7 to a competing owner.

[Storage incident and retained mounts](STORAGE_INCIDENT.md) records the authorized online2.33.5 recovery and Ray socket correction. Old inode domains remain intentionally retained until their users release them.


## 2026-10-13 U tau1/2/3 formal launch

User concluded EXPO FM-U tau2/3 and RLT Q-U tau2/3, releasing exactly6 cards. New pairs: tau1=SZ1 GPU6/7; tau2=SZ2 GPU4/5; tau3=SZ2 GPU6/7. The three Editor-U jobs remain unchanged.

Reuse the validated U source e04e9d4fbc and the actual September23 Clean256 resolved config: turn_switch,64x4=256 trajectories/round, group8, globalB512/micro32, update_epoch2, H50/D14,200-action cap, native Flow-SDE0.5 and original seeds/optimizer/filtering. Budget200 rounds, evaluation every2 rounds, checkpoint every10. Fresh original model/optimizer; no smoke checkpoint. Method delta is signal_source=ugrow_10_5, mode=apply, local/chunk tau=1/2/3, fixed alpha1, chunk_dropout=false and alpha schedules=false. No extra GPU smoke.

Historical controls already exist: Clean256107 rounds; DVCA tau1=108, tau2=98, tau3 resumed through70. Saved curves and configs are in formal1013/historical-baselines.json; these are existing partial runs, not completed200-round controls. No control was relaunched.

The only source change makes the existing graphics binding accept either the explicit4/5 or6/7 pair, preserving per-worker CUDA/renderer UUID validation and private process-name profiles. Two selected CPU scope tests passed. The three real launches each produced both assigned renderer UUID receipts. Existing driver and one CPU owner per host are reused without new permanent monitors: each card waits for its group's finished receipt, exact driver exit and its own C/G release, then starts its original RLT. All12 slots have valid configs/complete recovery points and live original owners.

Prepared configs, exact commands, baseline-only diffs, CPU validation, launch receipts and initial driver logs are under formal1013/sz1 and sz2. Server transaction: /data/chenyiteng/deployment-20261013/grpo-u-tau123-v1. Stop at200 rounds or on training failure/user stop; existing driver cleans only its exact Ray namespace. Initialization and rollout liveness are not evidence of learning gain.

12:05 China acceptance: all3 drivers and owners live; six renderer UUIDs match assigned cards. Tau1 completed its first256 trajectories and actor update: grad_norm27.669, weight range0.314-2.921, actor training23.441s, full round1292.6s; round2 sampling has started. Initial-policy sampling success was112/256, not a post-training evaluation. Tau2/3 each completed3/4 rollout batches in round1; no completed update yet. The initial-rollout receipts preserve exact progress and logs; no learning-gain claim is made.

## 2026-10-13 SZ2 reset timeout recovery

At13:08, tau2/3 exited after3 completed rounds: SubEnv25/0 reset futures exceeded120s at the next sampling round. Their exact namespaces cleared and the four original RLT fallbacks advanced normally. Historical Clean256107 rounds and DVCA tau1 108 rounds have no matching reset timeout in their saved driver logs. Before this repair, robotwin_env.py, env_worker.py and embodied_runner.py were byte-identical to the historical Clean source. The U signal and per-worker physical renderer binding are the intentional earlier differences; no evidence yet attributes the stall to either.

Native RoboTwin submits32 resets per EnvWorker but SubEnv.reset holds a shared lock during close/cache/scene setup. The120s future wait can therefore include queueing behind another reset. No thread stack survived the failed attempts, so the underlying blocking operation remains unproven; Gloo/Ray disconnect messages followed the reset failure.

The only runtime repair replaces VectorEnv.reset's result wait within this experiment's source: after120s dump all Python thread stacks, then wait on the same submitted future for up to600s total. Seeds, submission order, reset count, actions, concurrency, optimizer and200-round budget are unchanged. There is no retry, new watcher or shared RoboTwin asset edit. The existing October3 finite-wait approach is reused. Four CUDA-disabled tests cover the normal result, delayed completion on the same future, finite failure and an exception raised inside reset; Ruff checks pass.

With explicit user approval, paused only SZ2 GPU4-7 RLT and the original CPU owner, confirmed exact driver/namespace exit and C/G release, then relaunched tau2 on4/5 and tau3 on6/7 at16:17. The failed runs had no checkpoint before their first scheduled save at10, so both restart from the original base model. New transaction is `/data/chenyiteng/deployment-20261013/grpo-u-tau123-v1/retry-reset1`; run names append `-resetwait1` to the original names. Existing owner/driver code is unchanged. Each card again waits for its GRPO pair's exit and its own release, then resumes RLT from complete step550/300/450/475 respectively. Other hosts, users and shared Ray were not changed.

16:35 China acceptance: both runs completed2/4 rollout batches in round1 (128 trajectories each), with no new120s warning in the captured logs. Both drivers and the original owner are live; four slots are WAIT_EXTERNAL, all four complete fallback checkpoints remain available, and compute/renderer UUIDs stay on4-7 with0-3 clear. [Resetwait recovery](formal1013/sz2/resetwait-recovery.json) contains baseline comparison, config-only path changes, tests, cutover and acceptance. Separate driver tails preserve sampling progress. No actor update has completed yet, and startup success does not prove the original fourth-round failure is resolved.

## 2026-10-14 pillbottle task switch and approved storage cleanup

User explicitly approved the quoted primary151.2GiB cleanup and requested pillbottle with all other GRPO settings unchanged, still U tau1/2/3. All three live training/evaluation tasks were turn_switch. New train/eval task is move_pillbottle_pad; fresh original Sidney pi0.5 model/optimizer, exactly as the previous runs started. Pair allocation stays tau1=SZ1 GPU6/7, tau2=SZ2 GPU4/5, tau3=SZ2 GPU6/7.

Leaf comparison permits only task names, task-specific seed paths, and new run/graphics-receipt paths. Training remains64x4=256 trajectories/round, group8, globalB512/micro32, update_epoch2, H50/D14, M10, 200 physical actions, seed42, Flow-SDE0.5, max200 rounds, eval every2 and checkpoint every10. U10/5 uses fixed local/chunk tau1/2/3 and alpha1, with dropout/annealing disabled. No B1024 change. Existing source is reused in place; SZ2 retains the already deployed reset-wait fix. Existing train_seeds.json/eval_seeds.json match the historical C17 pillbottle lists exactly:1000 training seeds and320 evaluation candidates, with the original fixed32 evaluation selection. No new expert filtering or planner change.

Server transaction: `/data/chenyiteng/deployment-20261014/grpo-u-pillbottle-tau123-v1`; requests `tau1.json` on SZ1 and `tau2.json`/`tau3.json` on SZ2. `prepared.json` records exact commands and output paths; `diff-tauN.json` records every changed config leaf. Run names are `grpo-u-tau1-notrick-pillbottle256-sz1-g67-200-1014`, `grpo-u-tau2-notrick-pillbottle256-sz2-g45-200-1014`, and `grpo-u-tau3-notrick-pillbottle256-sz2-g67-200-1014` under the existing pi05-sidney/runs root. Stop at200 rounds, driver failure, or user request.

Paused only the existing CPU queue owners during cutover; signalled each old GRPO driver by its exact UID/PID/start identity. All old namespaces and selected C/G contexts cleared; exit receipts have cleanup_error=null. Existing EXPO, other users, shared Ray and original per-card fallback requests were preserved. Existing owner code resumed with the new driver identities and WAIT_EXTERNAL slots. Initial launch was blocked before driver initialization/GPU work by scope.json permissions0664; copying the original0600 mode and passing the existing CPU manifest validation resolved this. The failed startup logs/identities are retained separately. No training-source repair was introduced.

SZ1 storage transaction `/data/chenyiteng/deployment-20261014/storage-primary151-v1` removed exactly93 approved checkpoint directories,151.2032GiB allocated: GRPO CP10/20/30/40 and89 stopped RLT-BC intermediate points. GRPO CP50/60 and each selected RLT-BC run's latest checkpoint were verified before and after. Free/data increased321.6931→472.8954GiB; optional EXPO/cache and conditional old-BC files were outside this cleanup. Logs, curves and videos remain available. Exact deletion receipts and run evidence are indexed in [formal1014](formal1014/receipt.json).

13:55 China startup acceptance: all three new drivers and original CPU owners are live, each namespace has15 live actors, and all three logs entered first-round rollout generation. All six per-worker renderer UUIDs agree with their assigned CUDA/physical GPUs; no new GRPO context appears outside its assigned pair. The current owner slots wait on the corresponding new driver; original fallbacks and other priority slots are unchanged. Server `latest-check.json` and local `formal1014/*/startup-check.json` record acceptance. No full new-task update or evaluation has completed in this snapshot. With unchanged checkpoint frequency and approximately26.85GiB per saved round, twenty future checkpoints alone would require about537GiB on SZ1. The current cleanup does not cover that full-run storage estimate; no automatic retention policy was added.
