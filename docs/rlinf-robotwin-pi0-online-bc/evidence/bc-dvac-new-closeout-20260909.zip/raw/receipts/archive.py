"""Read the closed runs and archive lightweight evidence; never touch training files."""
import csv, datetime, hashlib, importlib.util, io, json, math, os, re, shutil, subprocess, zipfile
from pathlib import Path
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
ST = Path('/data/chenyiteng/results/server-maintenance-20260909/bc-dvac-new-closeout')
DEST = ST/'final-raw-v2'
spec=importlib.util.spec_from_file_location('formal_helpers', ST.parent.parent/'server-maintenance-20260908/bc-dvac-new-formal/ops.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
assert os.getuid()==1003 and subprocess.check_output(['hostname'],text=True).strip()=='admin'
stop=json.loads((ST/'stop-receipt.json').read_text());assert stop['completed']
DEST.mkdir(exist_ok=False)
def write(rel, data):
    p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True)
    if not isinstance(data,(bytes,str)):data=json.dumps(data,indent=2,ensure_ascii=False)
    with p.open('xb') as stream:stream.write(data.encode() if isinstance(data,str) else data)
for name in ('preflight.json','stop-attempt.json','stop-receipt.json','stop.py'):
    write('receipts/'+name,(ST/name).read_bytes())
write('receipts/archive.py',Path(__file__).read_bytes())
summary={'time':f.now(),'runs':{},'stop_completed':True}
retention={'policy':'All original checkpoints and success data retained in place; no deletion authorized in this closeout.', 'runs':{}}
total=0
for key in ('4u5','8u10'):
    s,root,run,ns,pre=f.select(key);rt=run/'runtime'
    assert f.h.git(root,'rev-parse','HEAD')==f.HEAD
    assert f.h.git(root,'status','--porcelain')==''
    assert (rt/'exit_code.txt').exists()
    expected=json.loads((rt/'driver-identity.json').read_text())
    try:cur=f.h.proc(expected['pid'])
    except FileNotFoundError:cur=None
    assert cur is None or any(cur[k]!=expected[k] for k in ('pid','uid','start'))
    paths=[p for p in run.iterdir() if p.is_file() and p.suffix in ('.log','.json','.yaml','.txt','.sh')]
    paths += [p for sub in ('runtime','tensorboard') for p in (run/sub).rglob('*') if p.is_file()]
    for p in sorted(set(paths)):
        assert not p.is_symlink() and p.resolve().is_relative_to(run)
        before=p.stat();assert before.st_size<50*1024**2
        data=p.read_bytes();after=p.stat()
        assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
        total+=len(data);assert total<180*1024**2
        assert not re.search(rb'-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY-----|(?:hf_|gh[pousr]_)[A-Za-z0-9]{30,}',data)
        write(f'runs/{key}/raw/{p.relative_to(run)}',data)
    ea=EventAccumulator(str(DEST/f'runs/{key}/raw/tensorboard'),size_guidance={'scalars':0});ea.Reload()
    scalars={tag:[{'raw_step':p.step,'round':p.step+1,'step':p.step+1,'value':p.value,'wall_time':p.wall_time} for p in ea.Scalars(tag)] for tag in ea.Tags()['scalars']}
    assert all(math.isfinite(p['value']) for points in scalars.values() for p in points)
    write(f'runs/{key}/scalars.json',scalars)
    output=io.StringIO();w=csv.writer(output);w.writerow(['tag','completed_round','raw_step','value','wall_time'])
    for tag,points in scalars.items():
        for p in points:w.writerow([tag,p['round'],p['raw_step'],p['value'],p['wall_time']])
    write(f'runs/{key}/scalars.csv',output.getvalue())
    files=[]
    for p in sorted(run.glob('*/checkpoints/global_step_*/**/*')):
        if p.is_file():
            assert p.resolve().is_relative_to(run)
            st=p.stat();files.append({'path':str(p),'relative_path':str(p.relative_to(run)),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'inode':st.st_ino,'device':st.st_dev})
    write(f'runs/{key}/checkpoint-inventory.json',files)
    rounds=sorted({int(re.search(r'/global_step_(\d+)/',row['path'])[1]) for row in files})
    train=scalars['env/success_once'];ev=scalars['eval/success_once']
    saved_eval=[p for p in ev if p['round'] in rounds]
    best=max(saved_eval,key=lambda p:p['value']) if saved_eval else None
    latest=max(rounds) if rounds else None
    keep_rounds=sorted({r for r in (latest,best['round'] if best else None) if r is not None})
    retention['runs'][key]={'run':str(run),'latest_saved_round':latest,'best_saved_fixed_eval':best,'minimum_keep_rounds':keep_rounds,'minimum_keep_files':[p for p in files if int(re.search(r'/global_step_(\d+)/',p['path'])[1]) in keep_rounds]}
    contract=json.loads((rt/'contract.json').read_text())
    srcs=set(contract['source_hashes'])|{'examples/embodiment/config/robotwin_adjust_bottle_online_bc_openpi.yaml','examples/embodiment/config/online_bc_model/pi05_sidney.yaml','examples/embodiment/config/bc_dvac/two_level_batch.yaml'}
    locks=[]
    for rel in sorted(srcs):
        data=(root/rel).read_bytes();sha=hashlib.sha256(data).hexdigest()
        if rel in contract['source_hashes']:assert sha==contract['source_hashes'][rel]
        write(f'runs/{key}/source/{rel}',data);locks.append({'path':rel,'sha256':sha,'bytes':len(data)})
    write(f'runs/{key}/source-lock.json',{'head':f.HEAD,'root':str(root),'files':locks})
    summary['runs'][key]={'run':str(run),'source_head':f.HEAD,'completed_rounds':train[-1]['round'],'recorded_training_attempts':train[-1]['round']*s['n'],'last_collection':train[-1],'last_fixed_eval':ev[-1],'best_fixed_eval':max(ev,key=lambda p:p['value']),'last_saved_round':latest,'checkpoint_file_count':len(files),'checkpoint_bytes':sum(p['bytes'] for p in files),'exit_code':(rt/'exit_code.txt').read_text().strip(),'finished_at':(rt/'finished_at.txt').read_text().strip(),'natural_completion':key=='4u5','termination':'natural R100' if key=='4u5' else 'user-authorized SIGTERM to exact driver; wrapper exit 134 recorded','train_ma5':sum(p['value'] for p in train[-5:])/5,'train_ma10':sum(p['value'] for p in train[-10:])/10,'latest_scalars':{t:ps[-1] for t,ps in scalars.items() if ps}}
write('SUMMARY.json',summary);write('RETENTION_MANIFEST.json',retention)
write('README.txt','Two closed BC DVAC new runs. Raw runtime/logs/config/TensorBoard scalars and reviewed source are included. Large model/optimizer/success-pool tensors remain at original server paths. This is an analysis/reproduction record, not a full recovery backup. Round = raw TensorBoard step + 1. A stopped in-flight round may have unlogged partial work.\n')
manifest=[{'path':str(p.relative_to(DEST)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(DEST.rglob('*')) if p.is_file()]
write('RAW_MANIFEST.json',manifest)
bundle=ST/'bc-dvac-new-final-raw.zip'
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(DEST.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(DEST))
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
receipt={'time':f.now(),'zip':str(bundle),'bytes':bundle.stat().st_size,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'file_count':len(manifest)+1,'summary':{key:{k:v for k,v in value.items() if k!='latest_scalars'} for key,value in summary['runs'].items()}}
f.save(ST/'archive-receipt.json',receipt,exclusive=True);print(json.dumps(receipt),flush=True)
