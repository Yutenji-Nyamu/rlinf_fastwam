"""Stop only the two explicitly identified new BC runs; retain all files."""
import datetime, importlib.util, json, os, pwd, signal, subprocess, time
from pathlib import Path
ST=Path('/data/chenyiteng/results/server-maintenance-20260909/bc-dvac-new-closeout')
path=Path('/data/chenyiteng/results/server-maintenance-20260908/bc-dvac-new-formal/ops.py')
spec=importlib.util.spec_from_file_location('formal_helpers',path)
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)

def same(expected):
    try:current=f.h.proc(expected['pid'])
    except FileNotFoundError:return False
    return all(current[k]==expected[k] for k in ('pid','uid','start'))

assert os.getuid()==1003 and pwd.getpwuid(os.getuid()).pw_name=='chenyiteng'
assert subprocess.check_output(['hostname'],text=True).strip()=='admin'
before=json.loads((ST/'preflight.json').read_text())
age=time.time()-datetime.datetime.fromisoformat(before['time']).timestamp()
assert 0<=age<900,age
protected=[p for gpu,dev in before['gpu'].items() if int(gpu) not in (6,7) for p in dev['processes']]
assert all(same(p) for p in protected)
target_ns={r['namespace'] for r in before['runs'].values()}
unrelated={r['actor_id'] for r in before['actors'] if r.get('ray_namespace') not in target_ns}
targets=[]
for key,row in before['runs'].items():
    assert row['source_head']=='e185219a9856521fcc705a96c9fd4d5eb5252b37' and row['source_status']==''
    assert f.h.git(row['root'],'rev-parse','HEAD')==row['source_head']
    identity=row['driver']
    rt=Path(row['run'])/'runtime'
    if not identity:
        assert row['exit_code']=='0' and (rt/'exit_code.txt').read_text().strip()=='0'
        continue
    if not same(identity):
        assert (rt/'exit_code.txt').exists() and (rt/'exit_code.txt').read_text().strip()=='0'
        continue
    assert identity['uid']==1003 and f'ops.py driver {key}' in identity['cmd']
    live=[r for r in f.actors() if r.get('ray_namespace')==row['namespace']]
    expected_job='6a020000' if key=='4u5' else '6b020000'
    assert live and all(r['job_id']==expected_job and f.h.proc(r['pid'])['uid']==1003 for r in live)
    targets.append({'key':key,'identity':identity,'namespace':row['namespace'],'job_id':expected_job})
attempt={'time':f.now(),'targets':targets,'authorized_scope':'Stop new BC4/U5 and BC8/U10 only; preserve checkpoints and all unrelated jobs'}
f.save(ST/'stop-attempt.json',attempt,exclusive=True)
for target in targets:
    assert same(target['identity'])
    os.kill(target['identity']['pid'],signal.SIGTERM)
deadline=time.monotonic()+50
while time.monotonic()<deadline and any(same(t['identity']) for t in targets):time.sleep(.5)
after_actors=f.actors();after_gpu=f.h.gpu_snapshot()
alive=[t for t in targets if same(t['identity'])]
remaining=[r for r in after_actors if r.get('ray_namespace') in target_ns]
missing=unrelated-{r['actor_id'] for r in after_actors}
result={'time':f.now(),'targets':targets,'alive_drivers':alive,'remaining_target_actors':remaining,
        'unrelated_missing_actor_ids':sorted(missing),'protected_unchanged':all(same(p) for p in protected),
        'gpu':after_gpu,'runs':{}}
for key,row in before['runs'].items():
    rt=Path(row['run'])/'runtime'
    result['runs'][key]={'run':row['run'],'exit_code':(rt/'exit_code.txt').read_text().strip() if (rt/'exit_code.txt').exists() else None,
       'finished_at':(rt/'finished_at.txt').read_text().strip() if (rt/'finished_at.txt').exists() else None,
       'cleanup':json.loads((rt/'owned-cleanup.json').read_text()) if (rt/'owned-cleanup.json').exists() else None}
result['completed']=not alive and not remaining and not missing and result['protected_unchanged']
f.save(ST/'stop-receipt.json',result,exclusive=True)
print(json.dumps(result),flush=True)
assert result['completed'],result
