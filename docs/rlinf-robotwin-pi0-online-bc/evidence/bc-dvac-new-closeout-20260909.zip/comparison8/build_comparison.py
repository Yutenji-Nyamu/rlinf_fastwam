"""Local-only rendering after the final new8 archive has been downloaded."""
import argparse
import html
import json
import statistics
import zipfile

import plot_experiment_refresh_20260908_1508 as b
from plot_bc4_all_methods_20260909 import pair_stats

p = b.p
ROOT = b.ROOT
EVIDENCE = ROOT / "docs/rlinf-robotwin-pi0-online-bc/evidence"
HIST = EVIDENCE / "bc8-u10-closeout-20260908/server_archive/bc-closeout-20260908.zip"
OUT = EVIDENCE / "bc-dvac-new-closeout-20260909/comparison8"


def adapt(data):
    return {tag:[{**point,"step":point.get("round",point.get("step"))} for point in points] for tag,points in data.items()}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--newzip', required=True)
    args=parser.parse_args()
    source=ROOT/args.newzip
    with zipfile.ZipFile(source) as z:
        assert z.testzip() is None
        new=adapt(json.loads(z.read('runs/8u10/scalars.json')))
    with zipfile.ZipFile(HIST) as z:
        clean=adapt(json.loads(z.read('scalars.json')))
    series={'clean8':clean,'new8':new}
    labels={'clean8':'历史干净BC · 长度过滤off','new8':'DVAC new · 长度过滤≤3'}
    runs={}
    for key,data in series.items():
        path=HIST if key=='clean8' else source
        runs[key]=b.make_run(labels[key],data,8,10,
            {'path':str(path.relative_to(ROOT)), 'sha256':b.digest(path),
             'member':'scalars.json' if key=='clean8' else 'runs/8u10/scalars.json'},historical=key=='clean8')
        expected=list(range(1,len(runs[key]['train'])+1))
        assert [point['step'] for point in runs[key]['train']]==expected
    cap=min(run['train'][-1]['step'] for run in runs.values())
    common=sorted(set(pt['step'] for pt in runs['clean8']['eval'] if pt['step']<=cap)&set(pt['step'] for pt in runs['new8']['eval'] if pt['step']<=cap))
    assert common and common==list(range(5,common[-1]+1,5))
    paired=pair_stats(runs,'clean8','new8',common)
    paired['tail_five']=pair_stats(runs,'clean8','new8',common[-5:])
    perrun={}
    for key,run in runs.items():
        perrun[key]={'label':labels[key], 'total_completed_rounds':run['train'][-1]['step'],
            'compared_rounds':cap,'training_attempts_compared':cap*8,
            'collection_successes_common':round(sum(pt['value']*8 for pt in run['train'] if pt['step']<=cap)),
            'collection_mean_pct_common':statistics.mean(pt['value'] for pt in run['train'] if pt['step']<=cap)*100,
            'last_matched':{metric:next(pt for pt in reversed(run[metric]) if pt['step']<=cap) for metric in ['train','ma5','ma10','eval']}}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'plots').mkdir(exist_ok=True)
    (OUT/'data').mkdir(exist_ok=True)
    for key,data in series.items(): b.dump(OUT/'data'/f'{key}-scalars.json',data)
    summary={'common_round_cap':cap,'paired_fixed':paired,'runs':perrun,
             'notes':['Final frozen new8 archive after user-authorized stop; baseline completed R100.',
                      'New also enables <=3 chunk success filtering. Differences are the method/filter combination.',
                      'Fixed32 checkpoints repeat the same scene set with one training seed; descriptive comparisons only.',
                      'Collection counts exclude evaluation; MA5/MA10 are full 40/80-attempt windows.']}
    b.dump(OUT/'summary.json',summary)
    b.dump(OUT/'data/chart_dataset.json',{'runs':runs,'summary':summary})
    b.save_csv(OUT/'data/curves.csv',[{'run':key,'metric':metric,**pt} for key,run in runs.items() for metric in ['train','ma5','ma10','eval'] for pt in run[metric]])
    p.COLORS.update({'clean8':'#C85A00','new8':'#7A35A4'})
    p.STYLES.update({'clean8':{'marker':'circle','dash':[]},'new8':{'marker':'triangle','dash':[17,6,3,6]}})
    p.RADII.update({'clean8':5,'new8':12})
    from datetime import datetime,timezone,timedelta
    stamp=datetime.fromtimestamp(new['env/success_once'][-1]['wall_time'],timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
    figures=[]; plotted=[]
    for metric,name in [('eval','固定32条评估'),('ma10','采集成功率 · MA10'),('ma5','采集成功率 · MA5'),('train','逐轮采集成功率')]:
        group={'id':'new8_closeout','title':f'π0.5 BC / DVAC new · 8/U10 · 共同前{cap}轮','keys':['clean8','new8'],'cap':cap,
               'note':'new开≤3 chunk成功过滤，历史干净BC关闭。固定评估只连实测点；MA5/MA10为40/80次训练采集。'}
        im,svg,points,title=p.chart(group,metric,name,runs,stamp)
        stem=f'new8_closeout_{metric}'
        im.save(OUT/'plots'/f'{stem}.png',optimize=True)
        (OUT/'plots'/f'{stem}.svg').write_text(svg,encoding='utf-8')
        figures.append({'stem':stem,'title':title})
        plotted.extend(points)
    b.save_csv(OUT/'data/plotted_points.csv',plotted)
    report=(f'# DVAC new 8/U10最终对照\n\n新8/U10最后完成R{runs["new8"]["train"][-1]["step"]}；历史干净BC已完成R100。四图均只比较共同前{cap}轮。\n\n'
            f'**共同fixed R{common[0]}–{common[-1]}，{len(common)}个检查点：new相对干净BC {paired["difference_pp"]:+.2f}个百分点，{paired["wins"]}胜{paired["ties"]}平{paired["losses"]}负。**\n\n'
            '| 指标 | 历史干净BC | DVAC new＋长度过滤 |\n|---|---:|---:|\n'
            f'| 共同fixed检查点均值 | {paired["reference_mean_pct"]:.2f}% | {paired["candidate_mean_pct"]:.2f}% |\n'
            f'| 最后5个共同fixed点均值 | {paired["tail_five"]["reference_mean_pct"]:.2f}% | {paired["tail_five"]["candidate_mean_pct"]:.2f}% |\n')
    for metric,label in [('train','最后共同轮采集'),('ma5','最后共同轮MA5'),('ma10','最后共同轮MA10')]:
        report+=f'| {label} R{cap} | {perrun["clean8"]["last_matched"][metric]["value"]:.2%} | {perrun["new8"]["last_matched"][metric]["value"]:.2%} |\n'
    report+=(f'| 前{cap}轮采集总体成功率 | {perrun["clean8"]["collection_mean_pct_common"]:.2f}% | {perrun["new8"]["collection_mean_pct_common"]:.2f}% |\n\n'
             '两组均为每轮8条/U10、batch1024/micro32，其余预算沿用各自对照。新版同时改变DVAC权重处理与成功长度过滤，差异按组合效果理解。'
             '每点fixed32为同一固定场景集重复评估，单seed结果；检查点不是独立重复。采集曲线不因长度过滤重定义，MA5/10不补未满窗口。\n\n'
             '[交互图册](index.html) · [完整曲线CSV](data/curves.csv) · [统计JSON](summary.json)。\n\n')
    blocks=[]
    for fig in figures:
        stem=fig['stem'];title=fig['title']
        report+=f'## {title}\n\n![{title}](plots/{stem}.png)\n\n[PNG](plots/{stem}.png) · [SVG](plots/{stem}.svg)\n\n'
        blocks.append('<article>'+(OUT/'plots'/f'{stem}.svg').read_text(encoding='utf-8')+f'<p><a href="plots/{stem}.png">PNG</a> · <a href="plots/{stem}.svg">SVG</a></p></article>')
    (OUT/'README.md').write_text(report,encoding='utf-8')
    choices=''.join(f'<label style="border-left:4px solid {p.COLORS[k]}"><input type="checkbox" data-run="{k}" checked>{html.escape(labels[k])}</label>' for k in runs)
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>BC 8/U10最终对比</title><style>body{font-family:"Microsoft YaHei",sans-serif;margin:0;background:#f5f8fb;color:#253d50}header{position:sticky;top:0;background:white;padding:12px 3%;z-index:2}label{display:inline-block;margin:5px 16px 5px 0;padding-left:5px}main{max-width:2000px;margin:auto;padding:12px 2%}article{background:white;margin:24px 0;padding:8px;overflow:auto}article>svg{display:block;width:100%;min-width:1000px}a{color:#006f73}</style><header><h1>π0.5 BC 8/U10最终对比 · 4张独立宽图</h1><p>CAP轮共同范围；new开成功过滤，历史对照off。</p>CHOICES<p><a href="README.md">说明与统计</a></p></header><main>BLOCKS</main><script>const checks=[...document.querySelectorAll('input[data-run]')];function update(){const visible=new Set(checks.filter(c=>c.checked).map(c=>c.dataset.run));document.querySelectorAll('svg [data-dependencies]').forEach(g=>g.style.display=g.dataset.dependencies.split(' ').every(k=>visible.has(k))?'':'none')}checks.forEach(c=>c.addEventListener('change',update));</script></html>'''
    (OUT/'index.html').write_text(page.replace('CAP',str(cap)).replace('CHOICES',choices).replace('BLOCKS','\n'.join(blocks)),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
