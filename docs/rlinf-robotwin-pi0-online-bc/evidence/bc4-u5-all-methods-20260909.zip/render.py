"""Local-only, matched-window comparison of three completed/frozen BC 4/U5 runs."""
import hashlib
import html
import itertools
import json
import shutil
import statistics
import zipfile
from pathlib import Path

import plot_experiment_refresh_20260908_1508 as b

p = b.p
ROOT = b.ROOT
EVIDENCE = ROOT / "docs/rlinf-robotwin-pi0-online-bc/evidence"
OLD = EVIDENCE / "bc4-u5-final-closeout-20260908"
SNAP = ROOT / "docs/server-admin/evidence/experiment-refresh-20260909/snapshot.json"
OUT = EVIDENCE / "bc4-u5-all-methods-20260909"
KEYS = ["clean", "old", "new"]
LABELS = {"clean": "干净BC · 长度过滤off", "old": "旧DVAC[0,5] · 长度过滤off", "new": "DVAC new · 长度过滤≤3"}


def measured(series, tag, cap=94):
    return [pt for pt in series.get(tag, []) if pt["step"] <= cap]


def last_value(series, tag, cap=94):
    rows = measured(series, tag, cap)
    return rows[-1]["value"] if rows else None


def pair_stats(runs, ref, candidate, rounds):
    maps = {k: {pt["step"]: pt["value"] for pt in runs[k]["eval"]} for k in [ref, candidate]}
    deltas = [maps[candidate][r] - maps[ref][r] for r in rounds]
    return {"reference": ref, "candidate": candidate, "rounds": rounds,
            "reference_mean_pct": statistics.mean(maps[ref][r] for r in rounds)*100,
            "candidate_mean_pct": statistics.mean(maps[candidate][r] for r in rounds)*100,
            "difference_pp": statistics.mean(deltas)*100,
            "wins": sum(d > 0 for d in deltas), "ties": sum(d == 0 for d in deltas),
            "losses": sum(d < 0 for d in deltas)}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "plots").mkdir(exist_ok=True)
    (OUT / "data").mkdir(exist_ok=True)
    snap = b.read(SNAP)
    source_paths = {"clean": OLD/"bc/scalars.json", "old": OLD/"dvac/scalars.json", "new": SNAP}
    series = {"clean": b.read(source_paths["clean"]), "old": b.read(source_paths["old"]),
              "new": snap["runs"]["new4"]["series"]}
    runs = {}
    for key in KEYS:
        b.dump(OUT / "data" / f"{key}-scalars.json", series[key])
        runs[key] = b.make_run(LABELS[key], series[key], 4, 5,
            {"path": source_paths[key].relative_to(ROOT).as_posix(), "sha256": b.digest(source_paths[key]),
             "selected_key": "runs.new4.series" if key == "new" else None}, historical=True)
        assert [pt["step"] for pt in runs[key]["train"]] == list(range(1, {"clean":101,"old":95,"new":101}[key]))
    b.dump(OUT / "data/new-config.json", snap["runs"]["new4"]["actual_config"])
    common = list(range(5, 91, 5))
    for key in KEYS:
        assert [pt["step"] for pt in runs[key]["eval"] if pt["step"] <=94] == common
    comparisons = {}
    for ref, candidate in itertools.combinations(KEYS, 2):
        name = f"{candidate}_vs_{ref}"
        comparisons[name] = pair_stats(runs, ref, candidate, common)
        comparisons[name]["tail_five"] = pair_stats(runs, ref, candidate, common[-5:])
        comparisons[name]["early_six"] = pair_stats(runs, ref, candidate, common[:6])
        comparisons[name]["middle_six"] = pair_stats(runs, ref, candidate, common[6:12])
        comparisons[name]["late_six"] = pair_stats(runs, ref, candidate, common[12:])
    stats = {}
    for key in KEYS:
        run = runs[key]
        stats[key] = {"label": LABELS[key], "completed_rounds": run["train"][-1]["step"],
            "collection_successes_first94": round(sum(pt["value"]*4 for pt in run["train"] if pt["step"]<=94)),
            "collection_rate_first94_pct": statistics.mean(pt["value"] for pt in run["train"] if pt["step"]<=94)*100,
            "ma5_at94_pct": next(pt["value"] for pt in run["ma5"] if pt["step"]==94)*100,
            "ma10_at94_pct": next(pt["value"] for pt in run["ma10"] if pt["step"]==94)*100,
            "ma5_at_final_pct": run["ma5"][-1]["value"]*100,
            "ma10_at_final_pct": run["ma10"][-1]["value"]*100,
            "latest_fixed": run["eval"][-1],
            "pool_at94": {tag.rsplit("/",1)[-1]: last_value(series[key], tag) for tag in
                ["train/replay_buffer/success_episodes", "train/replay_buffer/query_records", "train/replay_buffer/filtered_success_episodes"]},
            "pool_final": {tag.rsplit("/",1)[-1]: last_value(series[key], tag, 100) for tag in
                ["train/replay_buffer/success_episodes", "train/replay_buffer/query_records", "train/replay_buffer/filtered_success_episodes"]}}
        kept = stats[key]["pool_at94"]["success_episodes"]
        rejected = stats[key]["pool_at94"]["filtered_success_episodes"] or 0
        assert kept+rejected == stats[key]["collection_successes_first94"]
    diagnostics = {}
    for key, prefix in [("old", "train/dvac/"), ("new", "train/dvac_new/")]:
        diagnostics[key] = {}
        for metric in ["weight_mean", "weight_std", "weight_min", "weight_max", "local_std", "chunk_std", "coefficient_ess_fraction"]:
            pts = measured(series[key], prefix+metric)
            if pts:
                diagnostics[key][metric] = {"first_round": pts[0]["step"], "last_round":pts[-1]["step"],
                    "logged_points": len(pts), "mean_of_logged_values": statistics.mean(pt["value"] for pt in pts),
                    "minimum_logged_value": min(pt["value"] for pt in pts),
                    "maximum_logged_value": max(pt["value"] for pt in pts), "last": pts[-1]["value"]}
    extension = []
    for r in range(95, 101):
        row = {"round": r, "training_attempts": r*4}
        for key in ["clean", "new"]:
            for metric in ["train", "ma5", "ma10", "eval"]:
                pt = next((x for x in runs[key][metric] if x["step"]==r), None)
                row[f"{key}_{metric}_pct"] = pt["value"]*100 if pt else None
        extension.append(row)
    summary = {"source_snapshot_time_cst": snap["time_cst"], "matched_training_window": "R1–94 = 376 training attempts",
        "matched_fixed_window": "R5–90, 18 repeated fixed32 checkpoints", "runs":stats,
        "paired_fixed": comparisons, "new_vs_clean_all100": pair_stats(runs,"clean","new",list(range(5,101,5))),
        "weight_diagnostics_first94":diagnostics, "extension_R95_R100":extension,
        "cautions": ["New combines a new weighting transform and a <=3 chunk success-episode filter; other two runs have filtering disabled.",
            "Old logged weight statistics describe newly admitted data, whereas new logs aggregate actual sampled Adam batches: populations differ.",
            "All runs collect four episodes and use five Adam updates per round; fixed32 episodes are excluded from the sample axis.",
            "Single seed; repeated fixed32 checkpoints are correlated measurements, not independent replications."]}
    b.dump(OUT / "summary.json", summary)
    b.dump(OUT / "data/chart_dataset.json", {"runs":runs, "summary":summary})
    b.save_csv(OUT/"data/extension_R95_R100.csv", extension)
    curves = [{"run":key,"metric":metric, "cumulative_training_attempts":pt["step"]*4, **pt}
              for key in KEYS for metric in ["train","ma5","ma10","eval"] for pt in runs[key][metric]]
    b.save_csv(OUT/"data/curves.csv",curves)

    p.COLORS.update({"clean":"#C85A00", "old":"#006F73", "new":"#7A35A4"})
    p.STYLES.update({"clean":{"marker":"circle","dash":[]},
                    "old":{"marker":"square","dash":[15,9]},
                    "new":{"marker":"triangle","dash":[17,6,3,6]}})
    p.RADII.update({"clean":5, "old":10, "new":12})
    original_canvas = p.Canvas
    class ClearCountCanvas(original_canvas):
        def __init__(self):
            super().__init__()
            self.fixed_positions=[]
        def text(self,x,y,value,size=24,color=p.INK,anchor="la",max_width=None):
            if size==19 and anchor=="mm" and isinstance(value,int):
                while any(abs(x-px)<16 and abs(y-py)<19 for px,py in self.fixed_positions):
                    y+=22
                self.fixed_positions.append((x,y))
            super().text(x,y,value,size,color,anchor,max_width)
    p.Canvas=ClearCountCanvas
    figures, points = [], []
    stamp = snap["time_cst"][:19].replace("T"," ")
    for axis in ["round","samples"]:
        for metric,title in [("eval","固定32条评估"),("ma10","采集成功率 · MA10"),("ma5","采集成功率 · MA5"),("train","逐轮采集成功率")]:
            group={"id":f"bc4_all_{axis}","title":"π0.5 BC三组 · 4/U5 · 共同前94轮","keys":KEYS,"cap":94,"axis":axis,
                   "note":"旧DVAC止于R94；BC与new的R95–100见单独附表。new同时开≤3 chunk成功过滤，其余off。"}
            im, svg, rows, full_title = p.chart(group,metric,title,runs,stamp)
            stem=f"{group['id']}_{metric}"
            im.save(OUT/"plots"/f"{stem}.png", optimize=True)
            (OUT/"plots"/f"{stem}.svg").write_text(svg,encoding="utf-8")
            figures.append({"stem":stem,"title":full_title,"axis":axis,"metric":metric})
            points.extend(rows)
    b.save_csv(OUT/"data/plotted_points.csv", points)
    c=comparisons["new_vs_old"]
    report="# π0.5 4/U5：干净BC、旧DVAC与DVAC new\n\n"
    report+=(f"三组均为每轮4条、U5、batch1024/micro32。干净BC和new已完成R100，旧DVAC主动停止于R94。"
             f"本图册复用已落盘最终数据（new来源快照 {stamp} CST），不访问或改变服务器。\n\n"
             f"**共同R5–90：new相对旧DVAC {c['difference_pp']:+.2f}个百分点，{c['wins']}胜{c['ties']}平{c['losses']}负。** "
             f"新方法相对干净BC的增益不能证明它超过旧DVAC。new还同时开启成功长度过滤≤3 chunk；另外两组未过滤，归因需考虑此差异。\n\n")
    report+="| 比较（候选−参照） | 18个共同fixed点平均 | 胜/平/负 | 最后5个共同fixed点 R70–90 |\n|---|---:|---:|---:|\n"
    for name,row in comparisons.items():
        report+=f"| {LABELS[row['candidate']]} − {LABELS[row['reference']]} | {row['difference_pp']:+.2f} pp | {row['wins']}/{row['ties']}/{row['losses']} | {row['tail_five']['difference_pp']:+.2f} pp |\n"
    report+="\n| 共同窗口 | 干净BC | 旧DVAC | DVAC new＋长度过滤 |\n|---|---:|---:|---:|\n"
    for label,get in [
        ("fixed R5–90均值", lambda k:statistics.mean(pt["value"] for pt in runs[k]["eval"] if pt["step"]<=90)*100),
        ("fixed R5–30均值",lambda k:statistics.mean(pt["value"] for pt in runs[k]["eval"] if pt["step"]<=30)*100),
        ("fixed R35–60均值",lambda k:statistics.mean(pt["value"] for pt in runs[k]["eval"] if 35<=pt["step"]<=60)*100),
        ("fixed R65–90均值",lambda k:statistics.mean(pt["value"] for pt in runs[k]["eval"] if 65<=pt["step"]<=90)*100),
        ("R1–94采集成功率",lambda k:stats[k]["collection_rate_first94_pct"]),
        ("R94采集MA5",lambda k:stats[k]["ma5_at94_pct"]),
        ("R94采集MA10",lambda k:stats[k]["ma10_at94_pct"])]:
        report+=f"| {label} | "+" | ".join(f"{get(k):.2f}%" for k in KEYS)+" |\n"
    report+="\n**数据池与权重线索（共同R94）：**\n\n"
    report+="| 实验 | 累计采集成功 | 入池成功episode | 过滤成功episode | 池中query |\n|---|---:|---:|---:|---:|\n"
    for k in KEYS:
        row=stats[k]; pool=row["pool_at94"]
        report+=f"| {LABELS[k]} | {row['collection_successes_first94']} | {int(pool['success_episodes'])} | {int(pool['filtered_success_episodes'] or 0)} | {int(pool['query_records'])} |\n"
    nw=diagnostics["new"]; ow=diagnostics["old"]
    report+=(f"\n- new在R1–94的训练batch平均W为 {nw['weight_mean']['mean_of_logged_values']:.6f}，"
             f"各轮记录的W标准差均值 {nw['weight_std']['mean_of_logged_values']:.3f}；内层/外层标准差均值分别 "
             f"{nw['local_std']['mean_of_logged_values']:.3f}/{nw['chunk_std']['mean_of_logged_values']:.3f}。"
             "说明新归一化确实保持均重1，权重仍有变化；这不是无干预。\n"
             f"- 旧版有W记录的轮次（R{ow['weight_mean']['first_round']}–94）均值记录平均为 "
             f"{ow['weight_mean']['mean_of_logged_values']:.3f}，但旧版统计新入池样本，新版统计实际训练batch，不能把两者直接当同一分布比较。\n"
             "- 两版都保留高V增加模仿权重的方向；变化是新版的归一化范围、动态批内重算、均值约束以及长度过滤。当前曲线不能单独判断哪一项导致差异。\n"
             "- success_once始终统计采集是否成功；被长度过滤的成功轨迹仍算采集成功，只是不入训练池。\n"
             "- 不直接用两版加权actor_loss的绝对值判性能，因损失权重和数据组成不同。\n\n")
    report+="**R95–100补充（旧DVAC已停止，不补点、不外推）：**\n\n| 轮次 | BC原始采集 | new原始采集 | BC MA5/MA10 | new MA5/MA10 | BC/new fixed32 |\n|---|---:|---:|---:|---:|---|\n"
    for row in extension:
        ev="—" if row['clean_eval_pct'] is None else f"{round(row['clean_eval_pct']*.32)}/32、{round(row['new_eval_pct']*.32)}/32"
        report+=f"| R{row['round']} | {row['clean_train_pct']:.0f}% | {row['new_train_pct']:.0f}% | {row['clean_ma5_pct']:.1f}%/{row['clean_ma10_pct']:.1f}% | {row['new_ma5_pct']:.1f}%/{row['new_ma10_pct']:.1f}% | {ev} |\n"
    all100=summary['new_vs_clean_all100']
    report+=f"\n辅助比较完整R5–100：new相对BC {all100['difference_pp']:+.2f} pp，{all100['wins']}胜{all100['ties']}平{all100['losses']}负；不与旧DVAC不同终点混算。\n\n"
    report+=("所有比较均为单seed、同一固定32任务重复评估，检查点不是独立重复样本。MA5/10用完整过去5/10轮，分别对应20/40次训练采集，不补初始窗口。"
             "三组每轮采集数相同，因此轮次图与采样图形状相同，后者明确训练采样成本；横轴不含fixed评估采集。\n\n"
             "[交互图册：可隐藏任一曲线](index.html) · [完整曲线CSV](data/curves.csv) · [实际绘图点](data/plotted_points.csv) · [统计JSON](summary.json)。\n\n")
    blocks=[]
    for figure in figures:
        stem=figure['stem']; axis_label="累计训练采样" if figure['axis']=='samples' else "完成轮次"
        report+=f"## {axis_label} · {figure['title']}\n\n![{figure['title']}](plots/{stem}.png)\n\n[PNG](plots/{stem}.png) · [可编辑SVG](plots/{stem}.svg)\n\n"
        svg=(OUT/'plots'/f'{stem}.svg').read_text(encoding='utf-8')
        blocks.append(f'<article><h2>{axis_label}</h2>{svg}<p><a href="plots/{stem}.png">PNG</a> · <a href="plots/{stem}.svg">SVG</a></p></article>')
    (OUT/'README.md').write_text(report,encoding='utf-8')
    choices=''.join(f'<label style="border-left:4px solid {p.COLORS[k]}"><input type="checkbox" data-run="{k}" checked>{LABELS[k]}</label>' for k in KEYS)
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BC 4/U5 三组对比</title><style>body{font-family:"Microsoft YaHei",sans-serif;margin:0;background:#f5f8fb;color:#253d50}header{position:sticky;top:0;background:white;padding:12px 3%;z-index:2;border-bottom:1px solid #ddd}h1{font-size:24px;margin:5px 0}label{display:inline-block;margin:5px 16px 5px 0;padding-left:5px;font-size:14px}main{max-width:2000px;margin:auto;padding:12px 2%}article{background:white;margin:24px 0;padding:8px;overflow:auto}article>svg{display:block;width:100%;min-width:1000px}a{color:#006f73}article p,article h2{padding:0 25px}article h2{font-size:18px}</style><header><h1>π0.5 BC 4/U5 三组 · 8张独立宽图</h1><p>共同前94轮，fixed共同R5–90；new含长度过滤≤3，其余off。R95–100见说明中的独立附表。</p>CHOICES<p><a href="README.md">说明与统计</a> · <a href="data/curves.csv">完整曲线CSV</a> · <a href="summary.json">数值JSON</a></p></header><main>BLOCKS</main><script>const checks=[...document.querySelectorAll('input[data-run]')];function update(){const visible=new Set(checks.filter(c=>c.checked).map(c=>c.dataset.run));document.querySelectorAll('svg [data-dependencies]').forEach(g=>g.style.display=g.dataset.dependencies.split(' ').every(k=>visible.has(k))?'':'none')}checks.forEach(c=>c.addEventListener('change',update));</script></html>'''
    (OUT/'index.html').write_text(page.replace('CHOICES',choices).replace('BLOCKS','\n'.join(blocks)),encoding='utf-8')
    shutil.copy2(__file__,OUT/'render.py')
    shutil.copy2(ROOT/'local_scripts/plot_experiment_refresh_20260908_1508.py',OUT/'plot_experiment_refresh_20260908_1508.py')
    shutil.copy2(ROOT/'local_scripts/plot_expanded_training_comparison_20260908.py',OUT/'plot_expanded_training_comparison_20260908.py')
    manifest=[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':b.digest(f)} for f in sorted(OUT.rglob('*')) if f.is_file() and f.name!='MANIFEST.json']
    b.dump(OUT/'MANIFEST.json',manifest)
    archive=OUT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(OUT.rglob('*')):
            if f.is_file(): z.write(f,f.relative_to(OUT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for row in manifest: assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    receipt={'zip':str(archive),'bytes':archive.stat().st_size,'sha256':b.digest(archive),'files':len(manifest)+1,'crc_verified':True,'manifest_hashes_verified':True,'figures':len(figures)}
    b.dump(OUT.with_name(OUT.name+'-package.json'),receipt)
    print(json.dumps({'receipt':receipt,'paired_fixed':comparisons,'runs':stats},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
