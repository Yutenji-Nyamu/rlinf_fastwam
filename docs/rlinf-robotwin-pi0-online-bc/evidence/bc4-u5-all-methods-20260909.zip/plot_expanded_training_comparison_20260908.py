"""Render distinguishable experiment curves and an interactive local gallery."""

import argparse
import csv
import html
import json
import math
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


WIDTH, HEIGHT = 2000, 800
FONT = "C:/Windows/Fonts/msyh.ttc"
INK, MUTED, GRID, BG = "#253D50", "#607586", "#DEE6ED", "#F5F8FB"
COLORS = {
    "bc8_u10": "#C85A00", "dvac8_u10": "#006F73",
    "bc32_u10": "#7A35A4", "dvac32_u10": "#CC287C",
    "bc8_u2": "#176EBA", "dvac8_u2": "#566D00",
    "grpo_control": "#183F6C", "grpo_dvac": "#D23D20",
}
STYLES = {
    "bc8_u10": {"marker": "circle", "dash": [], "name": "橙圆 · 实线"},
    "dvac8_u10": {"marker": "square", "dash": [15, 9], "name": "深青方 · 虚线"},
    "bc32_u10": {"marker": "triangle", "dash": [17, 6, 3, 6], "name": "紫上三角 · 点划线"},
    "dvac32_u10": {"marker": "diamond", "dash": [27, 11], "name": "洋红菱形 · 长虚线"},
    "bc8_u2": {"marker": "cross", "dash": [3, 8], "name": "蓝叉 · 点线"},
    "dvac8_u2": {"marker": "triangle_down", "dash": [24, 7, 8, 7], "name": "深橄榄下三角 · 长短线"},
    "grpo_control": {"marker": "hexagon", "dash": [], "name": "海军蓝六边形 · 实线"},
    "grpo_dvac": {"marker": "star", "dash": [15, 9], "name": "朱红星 · 虚线"},
}
RADII = {"bc8_u10": 5, "dvac8_u10": 8, "bc32_u10": 10, "dvac32_u10": 10,
         "bc8_u2": 7, "dvac8_u2": 12, "grpo_control": 8, "grpo_dvac": 11}
METRICS = [("train", "逐轮采集成功率"), ("ma5", "采集成功率 · MA5"),
           ("ma10", "采集成功率 · MA10"), ("eval", "固定32条评估成功率")]


@lru_cache(maxsize=40)
def font(size):
    return ImageFont.truetype(FONT, size)


class Canvas:
    def __init__(self):
        self.image = Image.new("RGB", (WIDTH, HEIGHT), "white")
        self.draw = ImageDraw.Draw(self.image)
        self.svg = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {WIDTH} {HEIGHT}" role="img">',
                    '<rect width="100%" height="100%" fill="white"/>']

    def text(self, x, y, value, size=24, color=INK, anchor="la", max_width=None):
        value = str(value)
        while max_width and self.draw.textlength(value, font=font(size)) > max_width and size > 17:
            size -= 1
        self.draw.text((x, y), value, fill=color, font=font(size), anchor=anchor)
        align = {"l": "start", "m": "middle", "r": "end"}[anchor[0]]
        baseline = y + size if anchor[1] == "a" else y + size * 0.35
        self.svg.append(f'<text x="{x:.2f}" y="{baseline:.2f}" font-family="Microsoft YaHei,sans-serif" '
                        f'font-size="{size}" fill="{color}" text-anchor="{align}">{html.escape(value)}</text>')

    def rect(self, box, fill):
        self.draw.rectangle(box, fill=fill)
        x, y, right, bottom = box
        self.svg.append(f'<rect x="{x:.2f}" y="{y:.2f}" width="{right-x:.2f}" height="{bottom-y:.2f}" fill="{fill}"/>')

    def begin_run(self, key, dependencies=None):
        deps = " ".join(dependencies or [key])
        self.svg.append(f'<g data-run="{key}" data-dependencies="{deps}">')

    def end_run(self):
        self.svg.append('</g>')

    def line(self, coords, color, width=3, dash=None):
        if len(coords) < 2:
            return
        if not dash:
            self.draw.line(coords, fill=color, width=width, joint="curve")
        else:
            segment, remaining = 0, dash[0]
            for (x1, y1), (x2, y2) in zip(coords, coords[1:]):
                length, position = math.hypot(x2-x1, y2-y1), 0
                while position < length:
                    take = min(remaining, length-position)
                    if segment % 2 == 0:
                        a, b = position/length, (position+take)/length
                        self.draw.line([(x1+(x2-x1)*a, y1+(y2-y1)*a), (x1+(x2-x1)*b, y1+(y2-y1)*b)], fill=color, width=width)
                    position += take
                    remaining -= take
                    if remaining <= 1e-8:
                        segment = (segment+1) % len(dash)
                        remaining = dash[segment]
        ps = " ".join(f"{x:.2f},{y:.2f}" for x, y in coords)
        dash_attr = f' stroke-dasharray="{" ".join(map(str, dash))}"' if dash else ""
        self.svg.append(f'<polyline points="{ps}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round"{dash_attr}/>')

    def marker(self, x, y, color, radius, tooltip, shape="circle"):
        if radius:
            r = radius
            if shape == "circle":
                self.draw.ellipse((x-r, y-r, x+r, y+r), fill=color, outline=color, width=2)
                self.svg.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{color}" stroke="{color}" stroke-width="2"/>')
            elif shape == "cross":
                for a, b in [((x-r,y-r),(x+r,y+r)), ((x-r,y+r),(x+r,y-r))]:
                    self.line([a,b], color, 3)
            else:
                if shape == "square":
                    poly = [(x-r,y-r),(x+r,y-r),(x+r,y+r),(x-r,y+r)]
                elif shape == "diamond":
                    poly = [(x,y-r*1.3),(x+r,y),(x,y+r*1.3),(x-r,y)]
                elif shape in {"triangle", "triangle_down"}:
                    sign = 1 if shape == "triangle" else -1
                    poly = [(x,y-r*1.25*sign),(x+r*1.1,y+r*.8*sign),(x-r*1.1,y+r*.8*sign)]
                else:
                    count = 10 if shape == "star" else 6
                    poly = [(x+math.cos(-math.pi/2+i*2*math.pi/count)*r*(.48 if shape=="star" and i%2 else 1.25),
                             y+math.sin(-math.pi/2+i*2*math.pi/count)*r*(.48 if shape=="star" and i%2 else 1.25)) for i in range(count)]
                self.draw.line(poly+[poly[0]], fill=color, width=3, joint="curve")
                ps = " ".join(f"{px:.2f},{py:.2f}" for px,py in poly)
                self.svg.append(f'<polygon points="{ps}" fill="none" stroke="{color}" stroke-width="3" stroke-linejoin="round"/>')
        if tooltip:
            self.svg.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="11" fill="transparent"><title>{html.escape(tooltip)}</title></circle>')

    def finish(self):
        return "\n".join(self.svg + ["</svg>"])


def normalize(rows):
    result = []
    for row in rows:
        step, value = int(row["step"]), float(row["value"])
        if step < 1 or step != row["step"] or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f"Invalid measured point: {row}")
        result.append({"step": step, "value": value, "wall_time": row.get("wall_time"), "window_start": step})
    steps = [p["step"] for p in result]
    if steps != sorted(set(steps)):
        raise ValueError("Points must have unique, increasing displayed rounds")
    return result


def moving(points, window):
    result = []
    for i in range(window - 1, len(points)):
        chunk = points[i-window+1:i+1]
        if [p["step"] for p in chunk] != list(range(chunk[-1]["step"] - window + 1, chunk[-1]["step"] + 1)):
            continue
        result.append({"step": chunk[-1]["step"], "value": sum(p["value"] for p in chunk)/window,
                       "wall_time": chunk[-1]["wall_time"], "window_start": chunk[0]["step"]})
    return result


def nice_ticks(start, end, by_samples):
    span = max(1, end - start)
    base = 10 ** math.floor(math.log10(span / 8))
    stride = next(n * base for n in [1, 2, 2.5, 5, 10] if n * base >= span / 8)
    stride = max(1, math.ceil(stride))
    ticks = [start] + list(range(math.ceil(start/stride)*stride, end+1, stride)) + [end]
    ticks = sorted(set(ticks))
    if len(ticks) > 2 and ticks[1] - ticks[0] < stride * .38:
        ticks.pop(1)
    if len(ticks) > 2 and ticks[-1] - ticks[-2] < stride * .38:
        ticks.pop(-2)
    return ticks


def chart(group, metric, metric_name, runs, stamp):
    keys, cap = group["keys"], group.get("cap")
    sample_axis = group.get("axis") == "samples"
    xvalue = lambda key, point: point["step"] * (runs[key]["attempts_per_round"] if sample_axis else 1)
    visible = {key: [p for p in runs[key][metric] if (cap is None or p["step"] <= cap)
                    and (group.get("x_cap") is None or xvalue(key, p) <= group["x_cap"])] for key in keys}
    if not all(visible.values()):
        raise ValueError(f"Missing full-window data in {group['id']}/{metric}")
    end = max(xvalue(key, p) for key in keys for p in visible[key])
    if group.get("x_cap"):
        end = group["x_cap"]
    if not sample_axis:
        end = cap or max(p["step"] for key in keys for p in runs[key]["train"])
    start = min(runs[key]["attempts_per_round"] for key in keys) if sample_axis else 1
    start = group.get("x_min", start)
    c = Canvas()
    title = f"{group['title']} · {metric_name}"
    c.text(42, 17, title, 38, max_width=1905)
    axis_note = "累计采集条数 = 轮次 × 每轮条数" if sample_axis else "横轴为实际完成轮次"
    c.text(42, 76, f"快照 {stamp} CST  |  {axis_note}  |  颜色＋点形＋线型全图一致", 24, MUTED)
    for index, key in enumerate(keys):
        p, run = visible[key][-1], runs[key]
        col, row = index % 2, index // 2
        x, y = 42 + col * 975, 120 + row * 40
        label = run.get("plot_label", run.get("label", key))
        suffix = f"R{p['step']}：{p['value']*100:.2f}%"
        c.begin_run(key)
        c.line([(x, y+13), (x+82, y+13)], COLORS[key], 4, STYLES[key]["dash"])
        c.marker(x+41, y+13, COLORS[key], RADII[key], "", STYLES[key]["marker"])
        c.text(x+97, y-2, f"{label}  |  {suffix}", 24, COLORS[key], max_width=837)
        c.end_run()
    left, right, top, bottom = 108, 1925, 163 + math.ceil(len(keys)/2)*40, 660
    fx = lambda value: left + (value-start)/max(1, end-start)*(right-left)
    fy = lambda rate: bottom - rate*(bottom-top)
    common = group.get("shade_after")
    if common and common < end:
        c.rect((fx(common), top, right, bottom), "#F2F5F8")
        c.text(right-12, top+9, f"R{common}之后仅有历史Control", 22, MUTED, "ra")
    for value in [0, .25, .5, .75, 1]:
        c.line([(left, fy(value)), (right, fy(value))], GRID, 1)
        c.text(left-15, fy(value), f"{value:.0%}", 23, MUTED, "rm")
    for value in nice_ticks(start, end, sample_axis):
        c.line([(fx(value), top), (fx(value), bottom)], "#EEF2F5", 1)
        c.text(fx(value), bottom+25, f"{value:,}", 23, MUTED, "mm")
    c.text((left+right)/2, bottom+62, "累计采集条数" if sample_axis else "完成轮次", 25, MUTED, "mm")
    exported = []
    for index, key in enumerate(keys):
        pts, run, color = visible[key], runs[key], COLORS[key]
        coords = [(fx(xvalue(key, p)), fy(p["value"])) for p in pts]
        c.begin_run(key)
        c.line(coords, color, 4, STYLES[key]["dash"])
        spacing = 8 if len(pts) > 65 else 5
        phase = (list(COLORS).index(key)*2) % spacing
        for point_index, (p, (x, y)) in enumerate(zip(pts, coords)):
            budget = 32 if metric == "eval" else run["attempts_per_round"] * (p["step"]-p["window_start"]+1)
            successes = round(p["value"] * budget)
            label = run.get("plot_label", run.get("label", key))
            tooltip = f"{label} | R{p['window_start']}–{p['step']} | {p['value']*100:.5f}% | {successes}/{budget} | 累计采集 {p['step']*run['attempts_per_round']}条"
            show_marker = metric == "eval" or point_index % spacing == phase or p is pts[-1]
            c.marker(x, y, color, RADII[key] if show_marker else 0, tooltip, STYLES[key]["marker"])
            if metric == "eval" and len(keys) <= 3:
                others = [v["value"] for k in keys if k != key for v in visible[k] if xvalue(k, v) == xvalue(key, p)]
                offset = -20 if not others or p["value"] > max(others) or (p["value"] == max(others) and index == 0) else 21
                c.text(x, y+offset, successes, 19, color, "mm")
            exported.append({"chart": f"{group['id']}_{metric}", "run": key, "metric": metric,
                             "x_axis": "samples" if sample_axis else "round", "x": xvalue(key, p),
                             **p, "successes": successes, "attempts_in_point": budget})
        c.end_run()
    notes = {
        "train": "每个点为该轮在线采集成功率；各轮使用当轮采集策略。",
        "ma5": "MA5仅使用当前轮及之前4轮完整数据；缺轮不补值，从首个完整窗口开始。",
        "ma10": "MA10仅使用当前轮及之前9轮完整数据；缺轮不补值，从首个完整窗口开始。",
        "eval": ("每点32条固定评估；点旁数字为成功条数/32。折线仅连接实测点，SVG可悬停查看详情。" if len(keys) <= 3
                 else "每点32条固定评估；SVG悬停可看成功条数/32。折线仅连接实测点。"),
    }
    c.text(42, 740, notes[metric], 22, MUTED, max_width=1900)
    c.text(42, 768, group.get("note", ""), 18, MUTED, max_width=1900)
    return c.image, c.finish(), exported, title


def make_groups(runs):
    common = min(runs[k]["train"][-1]["step"] for k in ["grpo_control", "grpo_dvac"])
    bc_all = ["bc8_u10", "dvac8_u10", "bc32_u10", "dvac32_u10", "bc8_u2", "dvac8_u2"]
    groups = [
        {"id": "current_bc", "title": "π0.5 当前BC / DVAC · 8条/U10", "keys": bc_all[:2], "note": "当前DVAC范围[0,5]；两个实验均为seed42。"},
        {"id": "grpo_full", "title": "π0.5 GRPO Control / 逐动作DVAC · 完整历史", "keys": ["grpo_control", "grpo_dvac"], "shade_after": common, "note": "两项均256条/U2；当前DVAC保留baseline整chunk裁剪。"},
        {"id": "grpo_common", "title": f"π0.5 GRPO对比 · 共同前缀R1–{common}", "keys": ["grpo_control", "grpo_dvac"], "cap": common, "metrics": ["ma10", "eval"], "note": "仅放大双方都有记录的轮次；当前DVAC是独立实验。"},
        {"id": "bc_budgets", "title": "π0.5 BC · 三组预算", "keys": ["bc8_u10", "bc32_u10", "bc8_u2"], "note": "每轮采集条数与U同时见图例；曲线来自各自独立运行。"},
        {"id": "dvac_budgets", "title": "π0.5 BC＋DVAC · 三组预算", "keys": ["dvac8_u10", "dvac32_u10", "dvac8_u2"], "note": "当前DVAC为[0,5]，历史两项为[0,2]；方法配置及预算均有差别。"},
        {"id": "old_bc32_u10", "title": "π0.5 历史BC / DVAC · 32条/U10", "keys": ["bc32_u10", "dvac32_u10"], "note": "历史DVAC范围[0,2]；仅使用该次运行的实测记录。"},
        {"id": "old_bc8_u2", "title": "π0.5 历史BC / DVAC · 8条/U2", "keys": ["bc8_u2", "dvac8_u2"], "note": "历史DVAC范围[0,2]；仅使用该次运行的实测记录。"},
        {"id": "bc_all_rounds", "title": "π0.5 六组BC系列 · 按完成轮次", "keys": bc_all, "metrics": ["ma10", "eval"], "note": "统一颜色对应同一实验；6条曲线的完整数值可在SVG数据点或CSV查看。"},
        {"id": "bc_all_samples", "title": "π0.5 六组BC系列 · 按累计采集条数", "keys": bc_all, "axis": "samples", "metrics": ["ma10", "eval"], "note": "累计采集条数不含评估；MA10按10轮计算，各预算的窗口采集条数不同，更新预算U见图例。"},
        {"id": "bc_samples_early", "title": "π0.5 六组BC系列 · 前800条采集放大", "keys": bc_all, "axis": "samples", "x_min": 0, "x_cap": 800, "metrics": ["eval"], "note": "累计采集条数不含评估；仅放大横轴0–800条范围，不添加未测得的数据点。"},
        {"id": "current_bc_delta", "title": "π0.5 当前BC差值 · DVAC减BC", "keys": bc_all[:2], "kind": "delta", "metrics": ["ma10", "eval"], "note": "同完成轮次的DVAC成功率减BC成功率；单位为百分点。"},
        {"id": "grpo_delta", "title": "π0.5 GRPO共同范围差值 · DVAC减Control", "keys": ["grpo_control", "grpo_dvac"], "cap": common, "kind": "delta", "metrics": ["ma10", "eval"], "note": "只在双方都有记录的相同轮次相减；单位为百分点。"},
    ]
    return groups


def delta_chart(group, metric, metric_name, runs, stamp):
    base_key, dvac_key = group["keys"]
    base = {p["step"]: p for p in runs[base_key][metric]}
    method = {p["step"]: p for p in runs[dvac_key][metric]}
    common = min(runs[k]["train"][-1]["step"] for k in group["keys"])
    steps = sorted(s for s in base.keys() & method.keys() if s <= common)
    rows = [{"step": s, "value": method[s]["value"]-base[s]["value"], "window_start": method[s]["window_start"],
             "wall_time": method[s]["wall_time"], "baseline_value": base[s]["value"], "dvac_value": method[s]["value"]} for s in steps]
    if not rows:
        raise ValueError(f"No paired data for {group['id']}/{metric}")
    c, color, style = Canvas(), COLORS[dvac_key], STYLES[dvac_key]
    title = f"{group['title']} · {metric_name}"
    c.text(42, 17, title, 37, max_width=1905)
    c.text(42, 76, f"快照 {stamp} CST  |  同轮次实测差值  |  横轴为实际完成轮次", 24, MUTED)
    last = rows[-1]
    c.begin_run(dvac_key, group["keys"])
    c.line([(42, 133), (124, 133)], color, 4, style["dash"])
    c.marker(83, 133, color, RADII[dvac_key], "", style["marker"])
    c.text(139, 118, f"DVAC − baseline  |  R{last['step']}：{last['value']*100:+.2f} 个百分点", 27, color)
    c.end_run()
    left, right, top, bottom = 130, 1925, 203, 660
    bound = max(5, math.ceil(max(abs(p["value"])*100 for p in rows)/5)*5)
    fx = lambda s: left+(s-1)/max(1,common-1)*(right-left)
    fy = lambda pp: bottom-(pp+bound)/(2*bound)*(bottom-top)
    c.rect((left, top, right, fy(0)), "#F5FAF8")
    c.rect((left, fy(0), right, bottom), "#FCF7F4")
    for value in [-bound, -bound/2, 0, bound/2, bound]:
        c.line([(left, fy(value)), (right, fy(value))], "#5E707C" if value==0 else GRID, 3 if value==0 else 1)
        c.text(left-17, fy(value), f"{value:+g}" if value else "0", 24, MUTED, "rm")
    for step in nice_ticks(1, common, False):
        c.line([(fx(step), top), (fx(step), bottom)], "#E9EFF1", 1)
        c.text(fx(step), bottom+25, step, 23, MUTED, "mm")
    c.text((left+right)/2, bottom+62, "完成轮次", 25, MUTED, "mm")
    c.text(left+12, top+9, "DVAC较高（+）", 23, MUTED)
    c.text(left+12, bottom-34, "baseline较高（−）", 23, MUTED)
    c.begin_run(dvac_key, group["keys"])
    c.line([(fx(p["step"]), fy(p["value"]*100)) for p in rows], color, 4, style["dash"])
    exported = []
    for i, p in enumerate(rows):
        pp = p["value"]*100
        tooltip = f"R{p['step']} | DVAC {p['dvac_value']*100:.5f}% − baseline {p['baseline_value']*100:.5f}% = {pp:+.5f} 个百分点"
        c.marker(fx(p["step"]), fy(pp), color, RADII[dvac_key] if metric=="eval" or i%5==0 or p is rows[-1] else 0, tooltip, style["marker"])
        if metric=="eval":
            c.text(fx(p["step"]), fy(pp)+(-21 if pp>=0 else 23), f"{pp:+.2f}", 20, color, "mm")
        exported.append({"chart": f"{group['id']}_{metric}", "run": dvac_key, "metric": f"delta_{metric}",
                         "x_axis": "round", "x": p["step"], **p, "successes": "", "attempts_in_point": "",
                         "baseline_run": base_key, "delta_percentage_points": pp})
    c.end_run()
    c.text(42, 740, "正值表示DVAC较高，负值表示baseline较高；零线表示相等。仅展示这两次运行的观测差值。", 22, MUTED)
    c.text(42, 768, "MA10只使用完整10轮窗口；评估按相同实测轮次配对。", 18, MUTED)
    return c.image, c.finish(), exported, title


def gallery(out, groups, figures, stamp, runs):
    options = '<option value="all">全部展开图</option>' + "".join(f'<option value="{g["id"]}">{html.escape(g["title"])}</option>' for g in groups)
    blocks = []
    for group in groups:
        blocks.append(f'<section class="family" id="{group["id"]}"><h2>{html.escape(group["title"])}</h2><p>{html.escape(group.get("note", ""))}</p>')
        for figure in figures[group["id"]]:
            svg = (out/f"{figure['stem']}.svg").read_text(encoding="utf-8")
            blocks.append(f'<article id="{figure["stem"]}">{svg}'
                          f'<p><a href="{figure["stem"]}.png">独立PNG</a> · <a href="{figure["stem"]}.svg">SVG与数据悬停</a></p></article>')
        blocks.append('</section>')
    choices = []
    for key in COLORS:
        label = runs[key].get("plot_label", runs[key].get("label", key))
        choices.append(f'<label class="run-toggle" style="border-left:5px solid {COLORS[key]}"><input type="checkbox" data-toggle-run="{key}" checked> {html.escape(label)} <small>{STYLES[key]["name"]}</small></label>')
    page = '''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>π0.5 实验展开对比</title>
<style>body{font-family:"Microsoft YaHei",sans-serif;color:#253d50;background:#f5f8fb;margin:0}header{background:white;padding:16px 3%;position:sticky;top:0;z-index:3;border-bottom:1px solid #dce5eb}h1{font-size:24px;margin:0 0 8px}header p{margin:8px 0;font-size:14px}select,button{font:inherit;padding:6px;max-width:95%}button{cursor:pointer}a{color:#006f73}main{max-width:2000px;margin:auto;padding:20px 2%}.family{scroll-margin-top:270px}h2{font-size:24px;margin:22px 0 8px}.family>p{color:#607586}article{margin:22px 0;background:white;border-radius:10px;overflow-x:auto}article>svg{display:block;width:100%;min-width:1000px;aspect-ratio:2000/800}article p{padding:0 25px 15px;font-size:14px}.toggles{display:flex;flex-wrap:wrap;gap:6px 12px;margin:10px 0 0}.run-toggle{padding:4px 8px;background:#f5f8fb;cursor:pointer;font-size:13px;white-space:nowrap}.run-toggle small{color:#637580}details{margin-top:8px}summary{cursor:pointer;font-size:14px}</style></head><body>
<header><h1>π0.5 实验展开对比</h1><p>STAMP CST · 35张独立宽屏图，一图一行；实验在所有图中保持相同颜色、点形与线型。</p><label>选择图组 <select id="family">OPTIONS</select></label> · <a href="all_curves.csv">原始与滑动均值CSV</a> · <a href="plotted_points.csv">各图实际数据CSV</a> · <a href="statistics.json">统计与来源</a><details open><summary>选择显示的实验（差值图需同时选中对应双方）</summary><div class="toggles">CHOICES</div><button id="show-all" type="button">全部显示</button></details></header>
<main>BLOCKS</main><script>
const checks=[...document.querySelectorAll('[data-toggle-run]')];
function updateRuns(){const visible=new Set(checks.filter(c=>c.checked).map(c=>c.dataset.toggleRun));document.querySelectorAll('svg [data-dependencies]').forEach(g=>{g.style.display=g.dataset.dependencies.split(' ').every(k=>visible.has(k))?'':'none';});}
checks.forEach(c=>c.addEventListener('change',updateRuns));document.getElementById('show-all').addEventListener('click',()=>{checks.forEach(c=>c.checked=true);updateRuns();});
document.getElementById('family').addEventListener('change',e=>{document.querySelectorAll('.family').forEach(s=>s.hidden=e.target.value!=='all'&&s.id!==e.target.value);window.scrollTo({top:0});});if(location.hash){const key=location.hash.slice(1);const section=document.getElementById(key);if(section?.classList.contains('family')){document.getElementById('family').value=key;document.querySelectorAll('.family').forEach(s=>s.hidden=s.id!==key);}}
</script></body></html>'''
    page = page.replace("STAMP", stamp).replace("OPTIONS", options).replace("CHOICES", "".join(choices)).replace("BLOCKS", "\n".join(blocks))
    (out/"index.html").write_text(page, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", "--outdir", dest="output", type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8-sig"))
    runs = data["runs"]
    if set(runs) != set(COLORS):
        raise ValueError(f"Expected eight experiments, received {sorted(runs)}")
    if any(str(r.get("model", "")).replace("π", "pi").lower() not in {"pi0.5", "pi05", "0.5", "pi0.5 sidney", "pi05_sidney_robotwin"} for r in runs.values()):
        raise ValueError("All experiment models must explicitly resolve to pi0.5")
    for key, run in runs.items():
        run["train"], run["eval"] = normalize(run["train"]), normalize(run["eval"])
        run["ma5"], run["ma10"] = moving(run["train"], 5), moving(run["train"], 10)
        if not run["train"] or not run["eval"]:
            raise ValueError(f"Missing train or evaluation data: {key}")
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    stamp = data["time_cst"][:16].replace("T", " ")
    groups, figures, plotted = make_groups(runs), {}, []
    files = []
    for group in groups:
        figures[group["id"]] = []
        for metric, metric_name in METRICS:
            if metric not in group.get("metrics", [m for m, _ in METRICS]):
                continue
            render = delta_chart if group.get("kind") == "delta" else chart
            im, svg, rows, title = render(group, metric, metric_name, runs, stamp)
            stem = f"{group['id']}_{metric}"
            im.save(out/f"{stem}.png", optimize=True)
            (out/f"{stem}.svg").write_text(svg, encoding="utf-8")
            figures[group["id"]].append({"stem": stem, "title": title})
            plotted.extend(rows)
            files.extend([stem+".png", stem+".svg"])
    gallery(out, groups, figures, stamp, runs)
    with (out/"plotted_points.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for row in plotted for k in row)))
        writer.writeheader()
        writer.writerows(plotted)
    with (out/"all_curves.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["run", "label", "model", "metric", "step", "window_start", "value", "wall_time", "attempts_per_round", "update_epoch", "cumulative_samples", "seed", "status", "source"])
        for key, run in runs.items():
            for metric, _ in METRICS:
                for p in run[metric]:
                    writer.writerow([key, run.get("label"), run["model"], metric, p["step"], p["window_start"], p["value"], p["wall_time"], run["attempts_per_round"], run["update_epoch"], p["step"]*run["attempts_per_round"], run.get("seed"), run.get("status"), json.dumps(run.get("source"), ensure_ascii=False)])
    stats = {"time_cst": data["time_cst"], "source_dataset": str(args.input.resolve()), "colors": COLORS, "styles": STYLES, "marker_radii": RADII,
             "chart_count": sum(map(len, figures.values())), "groups": groups, "figures": figures,
             "validation": {"unique_increasing_rounds": True, "complete_contiguous_windows_only": True,
                            "sample_axis_equals_round_times_budget": True, "model": "pi0.5"},
             "runs": {key: {**{k:v for k,v in run.items() if k not in {m for m,_ in METRICS}},
                            "last": {metric: run[metric][-1] for metric,_ in METRICS},
                            "counts": {metric: len(run[metric]) for metric,_ in METRICS}}
                      for key, run in runs.items()}}
    (out/"statistics.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    files += ["index.html", "all_curves.csv", "plotted_points.csv", "statistics.json"]
    if stats["chart_count"] != 35 or not all((out/f).stat().st_size > 0 for f in files):
        raise ValueError("Incomplete chart delivery")
    print(json.dumps({"output": str(out.resolve()), "charts": stats["chart_count"], "file_count": len(files),
                      "total_bytes": sum((out/f).stat().st_size for f in files)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
