"""Render five concise charts from an existing local server snapshot."""

import csv
import hashlib
import html
import json
import zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

import plot_expanded_training_comparison_20260908 as p

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/server-admin/evidence/experiment-refresh-20260908-1508"
HISTORY = ROOT / "docs/server-admin/evidence/expanded-comparison-20260908-1055/dataset.json"
CONTROL = ROOT / "docs/rlinf-shenzhen-multitask-pi05/evidence/pi05-grpo-closeout-20260906/scalars.json"
OLD_DVAC = ROOT / "docs/server-admin/evidence/prism-bc4-cutover-20260908/receipts/old-grpo-closeout-20260908.zip"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def save_csv(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fields)
        writer.writeheader()
        writer.writerows(rows)


def make_run(label, series, attempts, updates, source, historical=False, run_path=None):
    train = p.normalize(series["env/success_once"])
    evaluation = p.normalize(series.get("eval/success_once", []))
    for points, denominator in [(train, attempts), (evaluation, 32)]:
        for pt in points:
            if abs(pt["value"]*denominator-round(pt["value"]*denominator)) > 1e-5:
                raise ValueError("Success count does not match its denominator")
    return {"label": label, "plot_label": label, "model": "pi0.5 Sidney",
            "attempts_per_round": attempts, "update_epoch": updates, "source": source,
            "historical": historical, "run_path": run_path, "train": train, "eval": evaluation,
            "ma5": p.moving(train, 5), "ma10": p.moving(train, 10)}


def main():
    snap = read(OUT/"snapshot.json")
    hist = read(HISTORY)["runs"]
    runs = {}
    for key, source_key, label in [
        ("bc4_u5", "bc", "当前 BC · 4条/U5"),
        ("dvac4_u5", "dvac", "当前 BC＋DVAC [0,5] · 4条/U5"),
        ("prism", "prism", "当前 Prism · 256条/U2"),
    ]:
        src = snap["runs"][source_key]
        attempts = int(src["series"]["env/num_trajectories"][0]["value"])
        if any(pt["value"] != attempts for pt in src["series"]["env/num_trajectories"]):
            raise ValueError("Per-round attempts changed")
        updates = int(src["actual_config"]["algorithm.update_epoch"])
        runs[key] = make_run(label, src["series"], attempts, updates,
                             {"file": "snapshot.json", "sha256": digest(OUT/"snapshot.json")}, run_path=src["run"])
        runs[key]["source_head"] = src["source_head"]
    control_series = read(CONTROL)
    runs["grpo_control"] = make_run("历史干净 Control · 256条/U2", control_series, 256, 2,
        {"file": str(CONTROL.relative_to(ROOT)), "sha256": digest(CONTROL)}, True, hist["grpo_control"]["run_path"])
    with zipfile.ZipFile(OLD_DVAC) as z:
        old_series = json.loads(z.read("scalars.json"))
        old_summary = json.loads(z.read("summary.json"))
    runs["grpo_dvac"] = make_run("历史逐动作DVAC · 256条/U2", old_series, 256, 2,
        {"file": str(OLD_DVAC.relative_to(ROOT)), "sha256": digest(OLD_DVAC), "member": "scalars.json"}, True, hist["grpo_dvac"]["run_path"])
    runs["grpo_dvac"]["archive_summary"] = old_summary
    p.COLORS.update({"bc4_u5": "#C85A00", "dvac4_u5": "#006F73", "prism": "#7A35A4"})
    p.STYLES.update({"bc4_u5": {"marker": "circle", "dash": [], "name": "橙实心圆 · 实线"},
                     "dvac4_u5": {"marker": "square", "dash": [15,9], "name": "深青空心方 · 虚线"},
                     "prism": {"marker": "triangle", "dash": [17,6,3,6], "name": "紫空心三角 · 点划线"}})
    p.RADII.update({"bc4_u5": 5, "dvac4_u5": 10, "prism": 12})
    base_canvas = p.Canvas
    class AllMarkersCanvas(base_canvas):
        def marker(self, x, y, color, radius, tooltip, shape="circle"):
            if tooltip and not radius:
                radius = next(p.RADII[k] for k in runs if p.COLORS[k] == color)
            super().marker(x, y, color, radius, tooltip, shape)
    p.Canvas = AllMarkersCanvas
    stamp = snap["time_cst"][:16].replace("T", " ")
    figures, plotted = [], []
    plot_dir = OUT/"plots"
    plot_dir.mkdir(exist_ok=True)
    def render(group, metric, name):
        im, svg, points, title = p.chart(group, metric, name, runs, stamp)
        stem = f"{group['id']}_{metric}"
        im.save(plot_dir/f"{stem}.png", optimize=True)
        (plot_dir/f"{stem}.svg").write_text(svg, encoding="utf-8")
        figures.append({"stem": stem, "title": title, "metric": metric, "group": group["id"]})
        plotted.extend(points)
    bc_group = {"id": "bc4_u5", "title": "π0.5 BC / DVAC · 当前4条/U5",
                "keys": ["bc4_u5", "dvac4_u5"],
                "note": "橙实心圆与深青大空心方均为真实位置；重合处保留两种点形，不平移数据。DVAC范围[0,5]。"}
    for metric, name in p.METRICS:
        render(bc_group, metric, name)
    cap = runs["prism"]["train"][-1]["step"]
    if cap < 1:
        raise ValueError("No complete Prism training point")
    grpo_group = {"id": "grpo_early", "title": f"π0.5 Prism / 历史GRPO · 共同前{cap}轮",
                  "keys": ["grpo_control", "grpo_dvac", "prism"], "cap": cap,
                  "note": f"Prism当前仅{cap}轮；MA5/MA10尚不足，首次fixed32在R5。历史Control封存168轮，逐动作DVAC封存59轮；本图仅取前{cap}轮。"}
    render(grpo_group, "train", "逐轮采集成功率")
    summary = {"snapshot_time_cst": snap["time_cst"], "figures": figures, "runs": {},
               "comparison_scope": f"BC current measured rounds; GRPO shared prefix R1-R{cap}"}
    curves=[]
    for key, run in runs.items():
        entry = {k:run[k] for k in ["label","source","historical","run_path","attempts_per_round","update_epoch"]}
        entry.update({"completed_rounds":run["train"][-1]["step"],"last_train":run["train"][-1],
                      "ma5":run["ma5"][-1] if run["ma5"] else None,
                      "ma10":run["ma10"][-1] if run["ma10"] else None,
                      "last_eval":run["eval"][-1] if run["eval"] else None,
                      "total_training_attempts":len(run["train"])*run["attempts_per_round"],
                      "total_training_successes":round(sum(pt["value"]*run["attempts_per_round"] for pt in run["train"]))})
        summary["runs"][key]=entry
        for metric in ["train","ma5","ma10","eval"]:
            for pt in run[metric]:
                curves.append({"run":key,"metric":metric,"historical":run["historical"],**pt})
    current_prism=snap["runs"]["prism"]["series"]
    summary["prism_diagnostics"]={tag:points[-1] for tag,points in current_prism.items() if tag.startswith("train/prism_dvac/") and points}
    dump(OUT/"chart_dataset.json", {"snapshot_time_cst":snap["time_cst"],"runs":runs})
    dump(OUT/"summary.json",summary)
    save_csv(OUT/"curves.csv",curves)
    save_csv(OUT/"plotted_points.csv",plotted)
    report=f"# 当前实验图册\n\n快照：{snap['time_cst']}（北京时间）。当前三组来自本次只读服务器快照；历史GRPO来自封存数据。\n\n"
    report+="| 当前实验 | 完成轮次 | 最新采集 | MA5 | MA10 | 最新fixed32 |\n|---|---:|---:|---:|---:|---|\n"
    for key in ["bc4_u5","dvac4_u5","prism"]:
        s=summary["runs"][key]
        ma5=f"{s['ma5']['value']:.2%}" if s["ma5"] else "不足5轮"
        ma10=f"{s['ma10']['value']:.2%}" if s["ma10"] else "不足10轮"
        evaluation=f"R{s['last_eval']['step']}：{round(s['last_eval']['value']*32)}/32" if s["last_eval"] else "尚无（首次R5）"
        report+=f"| {s['label']} | {s['completed_rounds']} | {s['last_train']['value']:.2%} | {ma5} | {ma10} | {evaluation} |\n"
    report+="\nBC每轮4条、U5，当前每点分母4；Prism每轮256条、U2，当前每点分母256。Prism前四轮成功数为97、92、109、98，末轮98/256=38.28125%。采集成功率对应当轮行为策略；固定评估在更新后进行。两种指标分别看。\n\n"
    report+=f"Prism当前只有{cap}轮，因此MA5、MA10与首次固定评估尚未形成；不生成空白图，也不补step0或窗口数据。GRPO图仅比较三条实测曲线的前{cap}轮，避免历史长曲线压缩当前变化。\n\n"
    report+="历史干净π0.5 Control封存168轮，最后fixed R165；历史逐动作正优势DVAC封存59轮，最后fixed R55。两者在图中明确标为历史，本次没有重跑。全部历史曲线及来源SHA256保留在chart_dataset.json和summary.json。\n\n"
    report+="MA5/MA10仅使用完整过去5/10轮；原始点全部显示，BC使用橙实心圆实线，DVAC使用更大的深青空心方虚线。GRPO历史Control为海军蓝空心六边形实线，历史DVAC为朱红空心星虚线，当前Prism为紫色空心三角点划线。数据点不平移。\n\n"
    report+="[当前状态与服务器概况](STATUS.md) · [交互图集](index.html) · [全部曲线CSV](curves.csv) · [实际绘图点CSV](plotted_points.csv) · [汇总和来源](summary.json)。\n\n"
    blocks=[]
    for f in figures:
        report+=f"## {f['title']}\n\n![{f['title']}](plots/{f['stem']}.png)\n\n[PNG](plots/{f['stem']}.png) · [SVG](plots/{f['stem']}.svg)\n\n"
        svg=(plot_dir/f"{f['stem']}.svg").read_text(encoding="utf-8")
        blocks.append(f'<article>{svg}<p><a href="plots/{f["stem"]}.png">PNG</a> · <a href="plots/{f["stem"]}.svg">SVG</a></p></article>')
    (OUT/"README.md").write_text(report,encoding="utf-8")
    choices="".join(f'<label><input type="checkbox" data-run="{key}" checked>{html.escape(run["label"])}</label>' for key,run in runs.items())
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>当前实验图册</title><style>body{font-family:"Microsoft YaHei",sans-serif;margin:0;color:#253d50;background:#f5f8fb}header{background:white;position:sticky;top:0;padding:12px 3%;z-index:2;border-bottom:1px solid #ddd}h1{font-size:24px;margin:6px 0}header p{font-size:14px;margin:8px 0}label{display:inline-block;margin:4px 16px 4px 0;font-size:14px}main{max-width:2000px;margin:auto;padding:12px 2%}article{background:white;margin:20px 0;padding:8px;overflow:auto}article>svg{display:block;width:100%;min-width:1000px}a{color:#006f73}article p{padding:0 25px}</style><header><h1>π0.5 当前实验 · 5张独立图</h1><p>STAMP CST。BC两组各19轮；Prism仅4轮，尚无MA5/MA10与fixed32。</p>CHOICES<p><a href="README.md">中文说明</a> · <a href="curves.csv">CSV</a> · <a href="summary.json">来源和统计</a></p></header><main>BLOCKS</main><script>const checks=[...document.querySelectorAll('input[data-run]')];function update(){const visible=new Set(checks.filter(c=>c.checked).map(c=>c.dataset.run));document.querySelectorAll('svg [data-dependencies]').forEach(g=>g.style.display=g.dataset.dependencies.split(' ').every(k=>visible.has(k))?'':'none')}checks.forEach(c=>c.addEventListener('change',update));</script></html>'''
    (OUT/"index.html").write_text(page.replace("STAMP",stamp).replace("CHOICES",choices).replace("BLOCKS","\n".join(blocks)),encoding="utf-8")
    print(json.dumps({"charts":len(figures),"out":str(OUT),"current":{k:summary["runs"][k] for k in ["bc4_u5","dvac4_u5","prism"]}},ensure_ascii=True))


if __name__=="__main__":
    main()
