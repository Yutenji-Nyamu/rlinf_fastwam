# π0.5 Clean BC · 4/U5续训收尾

用户于2026-09-12要求停止。完成记录至R174，最近固定评估R170=15/32；服务器最近完整checkpoint为R170。

本ZIP包含续训R101–174的完整driver日志、TensorBoard events、配置、命令、恢复/停止记录、全部标量CSV/JSON，以及合并原R1–100历史的指标与四张宽图（逐轮、MA5、MA10、固定评估）。

运行：`/home/chenyiteng/results/rlinf-shenzhen/online-bc/pi05-bc-clean-4u5-gpu6-resume100to200-20260911-v1`

原R100运行：`/home/chenyiteng/results/rlinf-shenzhen/online-bc/pi05-pillbottle-bc4x1-b1024-u5-m10-seed42-eval8x4-gpu6-formal100-20260908-v1`

源码：`e7b450f728775c5666ae185c8d03e8580ded0b67`；归档前分支HEAD：`5ec73515cb4a375e980c5d672d88d2d3a5d050e0`。

停止属于用户请求，runtime exit_code=134，不标成自然完成或exit0。SIGTERM后两driver及对应Ray actors均清除，其他作业保持；未删除模型、成功池或checkpoint，也未强制保存R174权重。大权重、回放池和视频不放进轻ZIP。

图中的R100竖线是续训边界。原clean长度过滤off、new≤3；模型/Adam/池等已恢复，但旧rollout随机状态和环境游标未保存，因此采集流在R101重新开始。历史标量与当前raw事件分别保留来源，合并CSV按实际完成轮次标记。

[四张图](plots/index.html) · [所有合并指标](metrics-merged.csv) · [原始日志](raw/runtime/driver.log) · [checkpoint清单](checkpoint-inventory.json)
