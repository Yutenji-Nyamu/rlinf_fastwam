# π0.5 BC / 旧DVAC 4/U5 收尾

2026-09-08 22:05 CST，按用户授权精确停止GPU7旧BC-DVAC。完成日志为 **R94/100**，最新固定评估R90；wrapper的exit_code=0不代表完成100轮。GPU6干净BC快照R96，继续运行；GPU4/5 Prism、其他GPU进程与共享Ray保持。

## 结果

共同固定评估R5–90共18次，DVAC **15胜、2平、1负**。检查点平均成功率 **42.88% → 49.48%，+6.60个百分点**。共同R90：BC 11/32、DVAC 15/32；DVAC最好已保存R60为21/32。固定32场景重复评估、单seed，检查点不是独立重复实验。

停止时：DVAC采集MA5=60%、MA10=52.5%；BC快照MA5=55%、MA10=57.5%。两组末轮不同，成对结论按共同轮次比较。

## 配置与身份

- 旧DVAC HEAD：`ad3da329270960f4ad378842e7138bbde29c521e`；旧分支`codex/sz-pi05-online-bc-dvac-w5`；源码/配置均未改动。
- 干净BC HEAD：`01d770db3988da7862454e97434d4ff08f726fa2`。
- 每轮4条，U5，batch1024/micro32，M10，chunk50，seed42；成功长度过滤关闭。
- 旧权重：logV、过去至多5轮统计、z裁剪、bounded_linear[0,5]，入池后W固定；新版在独立分支实现。
- 精确停止身份：UID1003、PID1785461/start173170246、Ray job52020000/namespace RLinf_1。[停止回执](stop-receipt.json)。

## 文件范围

含两组完整标量JSON/CSV、TensorBoard事件、driver/资源/metrics日志、实际配置/命令、关键源码及SHA、全部checkpoint文件清单、8张宽图PNG/SVG和作图点CSV。BC文件是同次读取的运行中快照。大模型、checkpoint张量、成功回放RGB、视频未复制。

[保留清单](RETENTION_MANIFEST.json)登记旧DVAC **R60、R90共10个模型/状态文件**，保留在原服务器路径；此前R60/R80保留清单继续有效。本包是轻量证据归档，不是完整训练恢复包。

## 一图一行

![pair4u5_round_eval](plots/pair4u5_round_eval.png)

![pair4u5_round_ma10](plots/pair4u5_round_ma10.png)

![pair4u5_round_ma5](plots/pair4u5_round_ma5.png)

![pair4u5_round_raw](plots/pair4u5_round_raw.png)

![pair4u5_samples_eval](plots/pair4u5_samples_eval.png)

![pair4u5_samples_ma10](plots/pair4u5_samples_ma10.png)

![pair4u5_samples_ma5](plots/pair4u5_samples_ma5.png)

![pair4u5_samples_raw](plots/pair4u5_samples_raw.png)

