"""Reuse accepted pinned Clean50 conversions; keep existing RLT until data ready."""
import concurrent.futures,importlib.util,json,os,subprocess,sys,time,traceback
from pathlib import Path
import yaml
D=Path('${DATA}/deployment-20261022/cp-multitask-sz2-g45');ROOT=Path('${DATA}/datasets/robotwin2')
def save(p,v):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,indent=2)+'\n');tmp.replace(p)
spec=importlib.util.spec_from_file_location('accepted_clean50',D/'data_worker.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
limits=yaml.safe_load(Path('${DATA}/projects/rlinf-shenzhen/RoboTwin-RLinf-support/task_config/_eval_step_limit.yml').read_text());assert len(limits)==50
save(D/'data-started.json',dict(time=time.time(),pid=os.getpid(),tasks=list(limits),revision=m.REV))
def one(task):
 found=[ROOT/'canonical/pi0-aloha-clean50-v1']if task=='adjust_bottle'else sorted((ROOT/'canonical').glob(task.replace('_','-')+'-aloha-clean50-*'))
 for p in reversed(found):
  if(p/'meta/info.json').is_file()and json.loads((p/'meta/info.json').read_text())['total_episodes']==50 and len(list(p.glob('data/*/episode_*.parquet')))==50:
   return task,p,'reused'
 archive=m.download(task)
 with(D/f'data-{task}.log').open('x')as log:
  r=subprocess.run([sys.executable,'-u','-B',str(D/'data_worker.py'),'--convert',task,str(archive)],stdout=log,stderr=subprocess.STDOUT,timeout=10800)
 assert r.returncode==0,f'{task}: conversion exit {r.returncode}; see task log'
 p=ROOT/'canonical'/(task.replace('_','-')+'-aloha-clean50-20261022')
 return task,p,'converted'
try:
 results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
  for f in concurrent.futures.as_completed([pool.submit(one,t)for t in limits]):
   task,p,origin=f.result();episodes=[json.loads(s)for s in(p/'meta/episodes.jsonl').read_text().splitlines()if s];windows=sum(max(0,e['length']-49)for e in episodes);assert len(episodes)==50 and windows>0
   results.append(dict(task=task,path=str(p),windows=windows,episodes=50,origin=origin,step_limit=limits[task]));save(D/'data-progress.json',dict(time=time.time(),completed=len(results),tasks=results));print(task,len(results),flush=True)
 results.sort(key=lambda x:x['task']);manifest={'revision':m.REV,'tasks':results,'total_windows':sum(x['windows']for x in results),'horizon':50,'sampler':'task_balanced_shuffled_window_cycles'}
 save(D/'data-manifest.json',manifest);save(D/'data-ready.json',dict(time=time.time(),tasks=50,episodes=2500,windows=manifest['total_windows'],steps_per_epoch=(manifest['total_windows']+127)//128,total_steps=50*((manifest['total_windows']+127)//128)))
except BaseException:
 save(D/'data-error.json',dict(time=time.time(),error=traceback.format_exc()));raise
