"""Complete the fixed 50-task manifest after finite download failures, reusing all finished conversions."""
import os,sys,json,time,subprocess,importlib.util,concurrent.futures,traceback
from pathlib import Path
S=Path('${DATA}/deployment-20261008/bc-signal-tau-v1');sys.path.insert(0,str(S/'ops'));from common import read,save,proc,same
D=Path('${DATA}/deployment-20261022/cp-multitask-sz2-g45');CAN=Path('${DATA}/datasets/robotwin2/canonical');tasks=read(D/'task-list.json')['tasks'];old=read(D/'data-launch.json')['identity'];save(D/'data-reconcile-identity.json',proc(os.getpid()))
spec=importlib.util.spec_from_file_location('accepted_data_worker',D/'data_worker.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def scan():
 rows=[]
 for t in tasks:
  candidates=[CAN/'pi0-aloha-clean50-v1']if t['task']=='adjust_bottle'else sorted(CAN.glob(t['task'].replace('_','-')+'-aloha-clean50-*'),reverse=True)
  for p in candidates:
   if not(p/'meta/info.json').is_file()or read(p/'meta/info.json')['total_episodes']!=50 or len(list(p.glob('data/*/episode_*.parquet')))!=50:continue
   episodes=[json.loads(s)for s in(p/'meta/episodes.jsonl').read_text().splitlines()if s];windows=sum(max(0,e['length']-49)for e in episodes)
   if len(episodes)!=50 or not windows:continue
   rows.append(dict(**t,path=str(p),windows=windows,episodes=50));break
 save(D/'data-live-progress.json',dict(time=time.time(),completed=len(rows),tasks=rows,initial_worker_alive=same(old)));return rows
def retry(t):
 task=t['task'];archive=m.download(task)
 with(D/f'data-{task}-retry.log').open('a')as log:
  result=subprocess.run([sys.executable,'-u','-B',str(D/'data_worker.py'),'--convert',task,str(archive)],stdout=log,stderr=subprocess.STDOUT,timeout=10800)
 assert result.returncode==0,f'{task}: conversion failed; preserve its partial files for inspection'
 return task
try:
 deadline=time.time()+12*3600
 while True:
  rows=scan()
  if len(rows)==50:break
  assert time.time()<deadline,'Data preparation exceeded12h; inspect failed tasks'
  if not same(old):
   present={r['task']for r in rows};missing=[t for t in tasks if t['task']not in present];errors={}
   with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
    futures={pool.submit(retry,t):t['task']for t in missing}
    for f in concurrent.futures.as_completed(futures):
     try:f.result()
     except Exception:errors[futures[f]]=traceback.format_exc()
     scan();save(D/'data-retry-errors.json',errors)
   rows=scan();assert len(rows)==50,dict(missing=[t['task']for t in tasks if t['task']not in{r['task']for r in rows}],errors=errors)
   break
  time.sleep(60)
 rows.sort(key=lambda x:x['task']);n=sum(r['windows']for r in rows);manifest=dict(revision=m.REV,tasks=rows,total_windows=n,horizon=50,sampler='task_balanced_shuffled_window_cycles')
 save(D/'data-manifest.json',manifest);save(D/'data-ready.json',dict(time=time.time(),tasks=50,episodes=2500,windows=n,steps_per_epoch=(n+127)//128,total_steps=50*((n+127)//128),complete=True));print(json.dumps(read(D/'data-ready.json')),flush=True)
except BaseException:save(D/'data-reconcile-error.json',dict(time=time.time(),error=traceback.format_exc()));raise
